"""
BDD Eligibility Checker
38 CFR § 3.816 / 38 U.S.C. § 5101(d)

Benefits Delivery at Discharge (BDD) requires:
  - Active duty service member
  - Separation date known (ETS/EAS/retirement)
  - Claim filed 90–180 days before separation
  - All required exams completed before separation
  - Minimum 180 days active duty service

Standard Claim (not BDD):
  - Filed less than 90 days before separation
  - Or filed after separation
"""

from datetime import date, timedelta
from typing import Dict, Optional, Tuple
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box
import questionary
from questionary import Style

STYLE = Style([
    ("qmark", "fg:cyan bold"),
    ("question", "bold"),
    ("answer", "fg:green bold"),
    ("pointer", "fg:cyan bold"),
    ("highlighted", "fg:cyan bold"),
    ("selected", "fg:green"),
    ("separator", "fg:yellow"),
    ("instruction", "fg:gray italic"),
])

console = Console()


def parse_date_input(prompt_text: str) -> Optional[date]:
    """Prompt user for a date and return a date object."""
    while True:
        val = questionary.text(
            prompt_text,
            instruction="(format: YYYY-MM-DD, e.g. 2024-09-30)",
            style=STYLE
        ).ask()

        if val is None:
            return None

        try:
            parts = val.strip().split("-")
            if len(parts) == 3:
                y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
                return date(y, m, d)
            raise ValueError
        except ValueError:
            console.print("[red]Invalid date format. Please use YYYY-MM-DD.[/red]")


def run_eligibility_check(storage=None) -> Dict:
    """
    Interactive BDD eligibility check.
    Returns a dict with eligibility status, claim type, and deadline information.
    """
    console.print()
    console.print(Panel(
        "[bold cyan]VA Benefits Delivery at Discharge (BDD) Eligibility Check[/bold cyan]\n\n"
        "This section determines whether you qualify for the BDD program and calculates\n"
        "your critical filing and exam completion deadlines.\n\n"
        "[dim]38 CFR § 3.816 | 38 U.S.C. § 5101(d)[/dim]",
        title="📋 Step 1: Eligibility",
        border_style="cyan"
    ))

    # ── Branch of Service ─────────────────────────────
    branch = questionary.select(
        "What is your branch of military service?",
        choices=["Army", "Navy", "Marine Corps", "Air Force", "Space Force", "Coast Guard", "National Guard / Reserves"],
        style=STYLE
    ).ask()

    if branch is None:
        return {"eligible": False, "reason": "Cancelled by user"}

    # ── Service Status ────────────────────────────────
    status = questionary.select(
        "What is your current service status?",
        choices=[
            "Active Duty — planning to separate/retire",
            "Active Duty — already separated",
            "National Guard / Reserve — on active orders (Title 10)",
            "National Guard / Reserve — not on active orders",
            "Already separated / veteran",
        ],
        style=STYLE
    ).ask()

    if status is None:
        return {"eligible": False, "reason": "Cancelled by user"}

    # ── Separation Date ───────────────────────────────
    today = date.today()
    separation_date = None
    days_until_separation = None
    claim_type = "standard"

    if "Active Duty" in status and "already separated" not in status:
        console.print("\n[bold]Enter your anticipated separation/ETS/retirement date:[/bold]")
        separation_date = parse_date_input("Separation date")

        if separation_date is None:
            return {"eligible": False, "reason": "Cancelled by user"}

        days_until_separation = (separation_date - today).days

        if days_until_separation < 0:
            console.print("[yellow]⚠  Your separation date appears to be in the past.[/yellow]")
            already_out = questionary.confirm(
                "Have you already separated from active duty?",
                style=STYLE
            ).ask()
            if already_out:
                status = "Already separated / veteran"
                days_until_separation = None
            else:
                console.print("[red]Please verify your separation date.[/red]")
                return {"eligible": False, "reason": "Invalid separation date"}

    # ── Entry Date (for minimum service check) ───────
    console.print("\n[bold]Enter your active duty entry date:[/bold]")
    entry_date = parse_date_input("Active duty entry date")

    total_service_days = None
    if entry_date and separation_date:
        total_service_days = (separation_date - entry_date).days
    elif entry_date:
        total_service_days = (today - entry_date).days

    # ── Determine Claim Type & Eligibility ───────────
    result = _assess_eligibility(
        status=status,
        separation_date=separation_date,
        today=today,
        days_until_separation=days_until_separation,
        total_service_days=total_service_days,
        branch=branch,
    )

    # ── Display Results ───────────────────────────────
    _display_eligibility_results(result, separation_date, today)

    # ── MOS / Rating ─────────────────────────────────
    mos = questionary.text(
        "What is your MOS/Rate/AFSC (military occupational specialty)?",
        instruction="(e.g., 11B, 0311, 18D, 68W — helps tailor claim strategy)",
        style=STYLE
    ).ask()

    rank = questionary.text(
        "What is your rank at separation?",
        instruction="(e.g., SGT, CPL, SSgt, PO2)",
        style=STYLE
    ).ask()

    result.update({
        "branch": branch,
        "status": status,
        "entry_date": str(entry_date) if entry_date else None,
        "separation_date": str(separation_date) if separation_date else None,
        "days_until_separation": days_until_separation,
        "total_service_days": total_service_days,
        "mos": mos,
        "rank": rank,
        "check_date": str(today),
    })

    # Save to storage if provided
    if storage:
        storage.set("eligibility", result)
        storage.set("service_info", {
            "branch": branch,
            "mos": mos,
            "rank": rank,
            "entry_date": str(entry_date) if entry_date else None,
            "separation_date": str(separation_date) if separation_date else None,
        })

    return result


def _assess_eligibility(
    status: str,
    separation_date: Optional[date],
    today: date,
    days_until_separation: Optional[int],
    total_service_days: Optional[int],
    branch: str,
) -> Dict:
    """Compute the eligibility status and deadlines."""

    # Already separated
    if "Already separated" in status or (days_until_separation is not None and days_until_separation < 0):
        return {
            "eligible": False,
            "claim_type": "standard",
            "reason": "You have already separated from active duty. You are not eligible for BDD, but you can file a standard VA disability claim at any time.",
            "action": "File a standard claim at va.gov or through your VSO.",
            "urgency": "normal",
        }

    # Not on active orders (Guard/Reserve without Title 10)
    if "not on active orders" in status:
        return {
            "eligible": False,
            "claim_type": "standard",
            "reason": "BDD requires active duty status or Title 10 active orders. As a Guard/Reserve member not on active orders, you must file a standard claim after any period of active duty.",
            "action": "File a standard claim after separation from any active duty period.",
            "urgency": "normal",
        }

    # Active duty with known separation date
    if days_until_separation is not None:

        # Minimum service check
        if total_service_days is not None and total_service_days < 180:
            return {
                "eligible": False,
                "claim_type": "standard",
                "reason": f"BDD requires at least 180 days of active duty service. Your calculated service is approximately {total_service_days} days.",
                "action": "Verify your entry date. If correct, file a standard claim.",
                "urgency": "normal",
            }

        if days_until_separation > 180:
            # Calculate when BDD window opens
            bdd_open_date = separation_date - timedelta(days=180)
            days_until_window = (bdd_open_date - today).days
            return {
                "eligible": False,
                "claim_type": "pre_bdd",
                "reason": f"You are {days_until_separation} days from separation — outside the 180-day BDD window.",
                "bdd_window_opens": str(bdd_open_date),
                "days_until_window": days_until_window,
                "action": f"Begin preparing your claim now. File on or after {bdd_open_date.strftime('%B %d, %Y')} ({days_until_window} days from today).",
                "urgency": "prepare_now",
                "exam_deadline": str(separation_date - timedelta(days=14)),
            }

        elif 90 <= days_until_separation <= 180:
            exam_deadline = separation_date - timedelta(days=14)
            filing_deadline = separation_date - timedelta(days=90)
            bdd_close_date = separation_date - timedelta(days=90)

            return {
                "eligible": True,
                "claim_type": "bdd",
                "reason": f"You are {days_until_separation} days from separation — within the BDD window (90–180 days).",
                "action": "File your BDD claim IMMEDIATELY. All C&P exams must be completed before separation.",
                "urgency": "urgent",
                "exam_deadline": str(exam_deadline),
                "filing_deadline": str(filing_deadline),
                "bdd_close_date": str(bdd_close_date),
                "days_remaining_in_window": days_until_separation - 90,
            }

        elif 1 <= days_until_separation < 90:
            return {
                "eligible": False,
                "claim_type": "ides_or_standard",
                "reason": f"You are {days_until_separation} days from separation — inside the 90-day minimum, which closes BDD eligibility.",
                "action": (
                    "File an Intent to File (ITF) TODAY at va.gov to lock in your effective date. "
                    "File a full standard claim as soon as possible. "
                    "If referred to IDES/LDES, that process applies instead."
                ),
                "urgency": "critical",
                "intent_to_file": "FILE TODAY",
            }

        elif days_until_separation == 0:
            return {
                "eligible": False,
                "claim_type": "standard",
                "reason": "You are separating today. File an Intent to File immediately.",
                "action": "File an ITF at va.gov now to protect your effective date.",
                "urgency": "critical",
            }

    return {
        "eligible": False,
        "claim_type": "standard",
        "reason": "Unable to determine eligibility from provided information.",
        "action": "Contact your VSO for assistance.",
        "urgency": "normal",
    }


def _display_eligibility_results(result: Dict, separation_date: Optional[date], today: date):
    """Display a rich formatted eligibility results panel."""
    console.print()

    urgency = result.get("urgency", "normal")
    claim_type = result.get("claim_type", "standard")
    eligible = result.get("eligible", False)

    # Color and icon by urgency
    border_color = {
        "urgent": "green",
        "critical": "red",
        "prepare_now": "yellow",
        "normal": "white",
    }.get(urgency, "white")

    icon = {
        True: "✅",
        False: "⚠️ ",
    }[eligible]

    claim_label = {
        "bdd": "[bold green]BDD (Benefits Delivery at Discharge)[/bold green]",
        "pre_bdd": "[bold yellow]Pre-BDD Window (Not Yet Eligible)[/bold yellow]",
        "ides_or_standard": "[bold red]Standard Claim (BDD Window Missed)[/bold red]",
        "standard": "[bold white]Standard VA Disability Claim[/bold white]",
    }.get(claim_type, "[bold white]Standard Claim[/bold white]")

    # Build deadline table if applicable
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan", padding=(0, 1))
    table.add_column("Milestone", style="bold")
    table.add_column("Date / Info", style="white")
    table.add_column("Status", justify="center")

    table.add_row("Today", str(today), "📅")

    if separation_date:
        days_out = (separation_date - today).days
        status_str = f"[green]{days_out}d away[/green]" if days_out >= 0 else "[red]PAST[/red]"
        table.add_row("Separation Date (ETS/EAS)", str(separation_date), status_str)

    if result.get("bdd_window_opens"):
        table.add_row("BDD Window Opens", result["bdd_window_opens"], "⏳")

    if result.get("bdd_close_date"):
        table.add_row("BDD Window Closes", result["bdd_close_date"], "⚠️ ")

    if result.get("exam_deadline"):
        table.add_row("C&P Exams Must Be Done By", result["exam_deadline"], "🩺")

    if result.get("filing_deadline"):
        table.add_row("Last Day to File (BDD)", result["filing_deadline"], "📝")

    content = (
        f"{icon} [bold]Claim Type:[/bold] {claim_label}\n\n"
        f"[bold]Assessment:[/bold] {result['reason']}\n\n"
        f"[bold]Your Next Action:[/bold] [yellow]{result.get('action', 'See VSO')}[/yellow]"
    )

    console.print(Panel(content, title="📋 Eligibility Result", border_style=border_color))
    console.print()
    console.print(table)
    console.print()

    if urgency == "urgent":
        console.print(Panel(
            "[bold red]⚡ TIME-SENSITIVE:[/bold red] You are in your BDD window RIGHT NOW.\n"
            "Every day you delay is a day less to complete your C&P exams before separation.\n"
            "File your claim this week. Contact your installation's TAP/ACAP office or VSO immediately.",
            border_style="red"
        ))

    elif urgency == "critical":
        console.print(Panel(
            "[bold red]🚨 CRITICAL ACTION REQUIRED:[/bold red]\n"
            "File an Intent to File (ITF) at va.gov TODAY — this locks in your effective date\n"
            "even if you cannot complete the full claim immediately.\n"
            "ITF URL: [link]https://www.va.gov/decision-reviews/intent-to-file/[/link]",
            border_style="red"
        ))

    elif urgency == "prepare_now":
        console.print(Panel(
            "[bold yellow]📝 START PREPARING NOW:[/bold yellow]\n"
            "You have time before your BDD window opens, but use it wisely.\n"
            "Begin documenting all conditions, gathering STRs, and visiting your doctor\n"
            "to get diagnoses on record before you file.",
            border_style="yellow"
        ))
