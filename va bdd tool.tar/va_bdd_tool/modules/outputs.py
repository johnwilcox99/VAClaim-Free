"""
Output Generation Module
Produces all claim documents:
  1. Printable summary PDF
  2. VA Form 21-526EZ language blocks
  3. C&P exam preparation sheet
  4. Nexus letter frameworks
"""

import os
import json
from pathlib import Path
from datetime import date
from typing import Dict, List, Optional
from rich.console import Console
from rich.panel import Panel
import questionary
from questionary import Style

STYLE = Style([
    ("qmark", "fg:cyan bold"),
    ("question", "bold"),
    ("answer", "fg:green bold"),
    ("pointer", "fg:cyan bold"),
])

console = Console()


def choose_output_directory() -> Path:
    """Let the veteran choose where to save their output files."""
    console.print()
    console.print(Panel(
        "[bold cyan]Output File Location[/bold cyan]\n\n"
        "Your claim documents will be saved to a location of your choosing.\n"
        "[yellow]⚠  These files will contain your personal health information.[/yellow]\n"
        "Store them securely and do not share them electronically without encryption.",
        border_style="cyan"
    ))

    default_path = str(Path.home() / "Desktop" / "VA_BDD_Claim")

    choice = questionary.select(
        "Where do you want to save your output files?",
        choices=[
            f"Desktop — {default_path}",
            "Documents folder",
            "Custom path — I'll enter it myself",
        ],
        style=STYLE,
    ).ask()

    if choice and "Desktop" in choice:
        out_dir = Path.home() / "Desktop" / "VA_BDD_Claim"
    elif choice and "Documents" in choice:
        out_dir = Path.home() / "Documents" / "VA_BDD_Claim"
    else:
        custom = questionary.text(
            "Enter the full path where files should be saved:",
            style=STYLE,
        ).ask()
        out_dir = Path(custom) if custom else Path.home() / "VA_BDD_Claim"

    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def generate_all_outputs(
    claim_data: Dict,
    output_dir: Path,
    ai_language: Optional[Dict] = None,
    cp_exam_prep: Optional[str] = None,
) -> List[Path]:
    """
    Generate all output documents. Returns list of file paths created.
    """
    files_created = []

    # 1. Claim Summary (plain text / markdown)
    summary_path = output_dir / "VA_BDD_Claim_Summary.txt"
    _write_claim_summary(claim_data, summary_path, ai_language)
    files_created.append(summary_path)
    console.print(f"[green]✓ Claim Summary → {summary_path}[/green]")

    # 2. 526EZ Language Blocks
    form_path = output_dir / "VA_526EZ_Language.txt"
    _write_526ez_language(claim_data, form_path, ai_language)
    files_created.append(form_path)
    console.print(f"[green]✓ 526EZ Language → {form_path}[/green]")

    # 3. C&P Exam Prep Sheet
    if cp_exam_prep:
        cp_path = output_dir / "CP_Exam_Prep_Sheet.txt"
        _write_cp_prep(cp_exam_prep, cp_path, claim_data)
        files_created.append(cp_path)
        console.print(f"[green]✓ C&P Prep Sheet → {cp_path}[/green]")

    # 4. Nexus Letter Frameworks
    nexus_data = claim_data.get("nexus_letters", {})
    if nexus_data:
        nexus_path = output_dir / "Nexus_Letter_Frameworks.txt"
        _write_nexus_letters(nexus_data, nexus_path, claim_data)
        files_created.append(nexus_path)
        console.print(f"[green]✓ Nexus Letter Frameworks → {nexus_path}[/green]")

    # 5. Rating Summary
    rating_path = output_dir / "Rating_Calculation_Summary.txt"
    _write_rating_summary(claim_data, rating_path)
    files_created.append(rating_path)
    console.print(f"[green]✓ Rating Summary → {rating_path}[/green]")

    # 6. Try PDF if reportlab available
    try:
        pdf_path = output_dir / "VA_BDD_Complete_Claim_Package.pdf"
        _write_pdf(claim_data, pdf_path, ai_language, cp_exam_prep)
        files_created.append(pdf_path)
        console.print(f"[green]✓ PDF Package → {pdf_path}[/green]")
    except ImportError:
        console.print("[dim]PDF generation skipped (reportlab not installed — run: pip install reportlab)[/dim]")

    return files_created


# ─────────────────────────────────────────────
# Individual File Writers
# ─────────────────────────────────────────────

def _write_claim_summary(claim_data: Dict, path: Path, ai_language: Optional[Dict]):
    today = date.today()
    elig = claim_data.get("eligibility", {})
    service = claim_data.get("service_info", {})
    conditions = claim_data.get("conditions", [])
    rating_result = claim_data.get("rating_result", {})

    lines = [
        "=" * 72,
        "   VA BDD CLAIM PREPARATION SUMMARY",
        f"   Generated: {today}",
        "=" * 72,
        "",
        "SECTION 1: SERVICE INFORMATION",
        "-" * 40,
        f"  Branch:           {service.get('branch', 'N/A')}",
        f"  MOS/Rate/AFSC:    {service.get('mos', 'N/A')}",
        f"  Rank:             {service.get('rank', 'N/A')}",
        f"  Entry Date:       {service.get('entry_date', 'N/A')}",
        f"  Separation Date:  {service.get('separation_date', 'N/A')}",
        "",
        "SECTION 2: BDD ELIGIBILITY",
        "-" * 40,
        f"  Claim Type:       {elig.get('claim_type', 'N/A').upper()}",
        f"  BDD Eligible:     {'YES' if elig.get('eligible') else 'NO'}",
        f"  Action Required:  {elig.get('action', 'N/A')}",
        "",
    ]

    if elig.get("exam_deadline"):
        lines.append(f"  ⚠  C&P Exam Deadline:  {elig['exam_deadline']}")
    if elig.get("filing_deadline"):
        lines.append(f"  ⚠  Filing Deadline:     {elig['filing_deadline']}")
    lines.append("")

    lines += [
        "SECTION 3: CONDITIONS CLAIMED",
        "-" * 40,
    ]

    for i, cond in enumerate(conditions, 1):
        lines += [
            f"",
            f"  {i}. {cond['condition_name']}",
            f"     Diagnostic Code:    {cond['diagnostic_code']}",
            f"     CFR Reference:      {cond.get('cfr_reference', 'See 38 CFR Part 4')}",
            f"     Estimated Rating:   {cond['estimated_rating']}%",
            f"     In-Service Event:   {'; '.join(cond.get('in_service_events', ['Not specified']))}",
            f"     STRs Documentation: {cond['symptoms'].get('strs_documentation', 'Unknown')}",
            f"     Treatments:         {', '.join(cond['symptoms'].get('treatments', ['None listed']))}",
        ]

        if ai_language and cond["condition_key"] in ai_language:
            lang = ai_language[cond["condition_key"]]
            lines += [
                f"",
                f"     526EZ CLAIM LANGUAGE:",
                f"     {lang.get('form_language', 'See 526EZ Language file')}",
            ]

    lines += [
        "",
        "SECTION 4: COMBINED RATING CALCULATION",
        "-" * 40,
    ]

    if rating_result:
        lines += [
            f"  Individual Ratings:   {rating_result.get('all_ratings_used', [])}",
            f"  Raw Combined:         {rating_result.get('combined_raw', 0):.2f}%",
            f"  Final Combined:       {rating_result.get('combined_final', 0)}%",
            f"",
            f"  TDIU Eligible:        {'YES' if rating_result.get('tdiu_eligible') else 'No'}",
        ]
        if rating_result.get("tdiu_reason"):
            lines.append(f"  TDIU Reason:          {rating_result['tdiu_reason']}")

        comp = claim_data.get("compensation_estimate", {})
        if comp:
            lines += [
                "",
                f"  Estimated Monthly Compensation (2024 rates):",
                f"    Base (no dependents): ${comp.get('base_monthly', 0):,.2f}/month",
                f"    Annual Estimate:      ${comp.get('annual_estimate', 0):,.2f}/year",
                f"  {comp.get('disclaimer', '')}",
            ]

    lines += [
        "",
        "=" * 72,
        "  IMPORTANT NOTICES",
        "=" * 72,
        "",
        "  1. This document is a preparation tool only. Final ratings are",
        "     determined by the VA based on C&P exam findings and medical evidence.",
        "",
        "  2. All language in this document is based on your reported symptoms.",
        "     Do not submit anything that is inaccurate or exaggerated.",
        "",
        "  3. Consult a VSO (Veterans Service Organization) or accredited claims",
        "     agent for professional review before filing.",
        "",
        "  4. Free VSO assistance: DAV, VFW, American Legion, AMVETS, WWP",
        "     Find a VSO: https://www.va.gov/decision-reviews/get-help-with-review-request/",
        "",
        "  5. This file contains Protected Health Information (PHI).",
        "     Store it securely and share only with authorized individuals.",
        "",
        "=" * 72,
    ]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    os.chmod(path, 0o600)


def _write_526ez_language(claim_data: Dict, path: Path, ai_language: Optional[Dict]):
    conditions = claim_data.get("conditions", [])
    service = claim_data.get("service_info", {})
    today = date.today()

    lines = [
        "=" * 72,
        "   VA FORM 21-526EZ — CLAIM LANGUAGE BLOCKS",
        f"   Generated: {today}",
        "   Copy these descriptions into the appropriate fields on VA Form 21-526EZ",
        "=" * 72,
        "",
        "HOW TO USE THIS FILE:",
        "  • Each section below corresponds to one condition on your 526EZ.",
        "  • Copy the 'CLAIM LANGUAGE' into the 'Name of Disability' and",
        "    'Describe Your Disability' fields on the form.",
        "  • Review and personalize each block with your specific details.",
        "  • The form is available at: https://www.va.gov/disability/apply/",
        "",
        "=" * 72,
        "",
    ]

    for i, cond in enumerate(conditions, 1):
        lang = (ai_language or {}).get(cond["condition_key"], {})

        lines += [
            f"CONDITION {i}: {cond['condition_name'].upper()}",
            f"Diagnostic Code: {cond['diagnostic_code']}",
            "-" * 60,
            "",
            "CLAIM LANGUAGE (copy to 526EZ):",
            ">>>",
            lang.get("form_language", f"[PENDING AI GENERATION] — {cond['condition_name']}"),
            "<<<",
            "",
            "NEXUS STATEMENT (service connection):",
            ">>>",
            lang.get("nexus_language",
                     f"This condition is at least as likely as not caused by or related to the veteran's "
                     f"military service with {service.get('branch', '[Branch]')} as a {service.get('mos', '[MOS]')}."),
            "<<<",
            "",
        ]

        if lang.get("key_phrases"):
            lines += [
                "KEY PHRASES (ensure these appear in your claim):",
                "  " + " | ".join(lang["key_phrases"]),
                "",
            ]

        if lang.get("suggested_personalization"):
            lines += [
                "PERSONALIZATION NOTES:",
                f"  {lang['suggested_personalization']}",
                "",
            ]

        if lang.get("rating_justification"):
            lines += [
                f"RATING JUSTIFICATION ({lang.get('target_rating_percentage', cond['estimated_rating'])}%):",
                f"  {lang['rating_justification']}",
                "",
            ]

        lines += ["=" * 72, ""]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    os.chmod(path, 0o600)


def _write_cp_prep(cp_prep_text: str, path: Path, claim_data: Dict):
    today = date.today()
    elig = claim_data.get("eligibility", {})

    header = [
        "=" * 72,
        "   C&P EXAM PREPARATION GUIDE",
        f"   Generated: {today}",
        "=" * 72,
        "",
    ]

    if elig.get("exam_deadline"):
        header += [
            f"  ⚠  YOUR EXAM MUST BE COMPLETED BY: {elig['exam_deadline']}",
            "  Contact your MTF or VA exam scheduler immediately to schedule.",
            "",
        ]

    footer = [
        "",
        "=" * 72,
        "  YOUR RIGHTS AT THE C&P EXAM",
        "=" * 72,
        "",
        "  • You may bring a VSO representative to your exam.",
        "  • You may bring a support person (family/friend — they observe only).",
        "  • You may request a copy of the DBQ after the exam.",
        "  • If the examiner is rushed or dismissive, note this — you can request",
        "    a new exam or submit a rebuttal statement.",
        "  • The examiner WORKS FOR THE VA but has no power to grant or deny —",
        "    they only report findings. Be thorough and accurate.",
        "  • You have the right to submit a personal statement (VA Form 21-4138)",
        "    to supplement the exam findings.",
        "",
        "  AFTER YOUR EXAM:",
        "  • Request a copy of the DBQ completed by the examiner.",
        "  • Review it carefully — if it misrepresents your symptoms, you can",
        "    submit a rebuttal or request a new exam.",
        "",
        "=" * 72,
    ]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(header))
        f.write(cp_prep_text)
        f.write("\n".join(footer))
    os.chmod(path, 0o600)


def _write_nexus_letters(nexus_data: Dict, path: Path, claim_data: Dict):
    today = date.today()

    lines = [
        "=" * 72,
        "   NEXUS LETTER FRAMEWORKS",
        f"   Generated: {today}",
        "=" * 72,
        "",
        "INSTRUCTIONS FOR YOUR TREATING PHYSICIAN:",
        "  • These are FRAMEWORKS — your doctor must review, modify, and sign.",
        "  • The physician must use language that 'at least as likely as not'",
        "    connects the condition to military service.",
        "  • The letter should be on physician letterhead with signature and",
        "    medical license number.",
        "  • A private nexus letter carries significant weight in VA adjudication.",
        "",
        "=" * 72,
        "",
    ]

    for condition_key, letter_text in nexus_data.items():
        from data.conditions_db import CONDITIONS_DB
        cond_name = CONDITIONS_DB.get(condition_key, {}).get("name", condition_key)
        lines += [
            f"NEXUS LETTER: {cond_name.upper()}",
            "-" * 60,
            "",
            letter_text,
            "",
            "=" * 72,
            "",
        ]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    os.chmod(path, 0o600)


def _write_rating_summary(claim_data: Dict, path: Path):
    today = date.today()
    rating_result = claim_data.get("rating_result", {})
    conditions = claim_data.get("conditions", [])
    comp = claim_data.get("compensation_estimate", {})

    lines = [
        "=" * 72,
        "   VA COMBINED RATING CALCULATION",
        f"   Per 38 CFR § 4.25 (Combined Ratings Table)",
        f"   Generated: {today}",
        "=" * 72,
        "",
        "VA COMBINED RATINGS METHOD ('Whole Person' Formula):",
        "  The VA does not simply add percentages. It uses the 'whole person'",
        "  method: each disability is applied to the remaining efficient person.",
        "  The final combined value is rounded to the nearest 10%.",
        "",
        "YOUR CONDITIONS AND INDIVIDUAL RATINGS:",
        "-" * 40,
    ]

    for cond in conditions:
        bilateral_note = " [BILATERAL PAIR]" if cond.get("bilateral_pair") else ""
        lines.append(
            f"  {cond['condition_name']:<40} {cond['estimated_rating']:>3}%{bilateral_note}"
        )

    lines += [""]

    if rating_result.get("bilateral_adjustments"):
        lines += ["BILATERAL FACTOR ADJUSTMENTS (38 CFR § 4.26):", "-" * 40]
        for adj in rating_result["bilateral_adjustments"]:
            lines += [
                f"  {adj['left'][0]} ({adj['left'][1]}%) + {adj['right'][0]} ({adj['right'][1]}%)",
                f"    Combined bilateral:    {adj['combined_before_factor']}%",
                f"    + 10% bilateral bonus: +{adj['bilateral_bonus']}%",
                f"    Adjusted value:        {adj['adjusted_rating']}%",
                "",
            ]

    lines += [
        "COMBINED RATING CALCULATION:",
        "-" * 40,
        f"  Input ratings (sorted):  {rating_result.get('all_ratings_used', [])}",
        f"  Raw combined value:      {rating_result.get('combined_raw', 0):.2f}%",
        f"  Rounded to nearest 10%: {rating_result.get('combined_final', 0)}%",
        "",
        f"  *** ESTIMATED COMBINED RATING: {rating_result.get('combined_final', 0)}% ***",
        "",
    ]

    if rating_result.get("tdiu_eligible"):
        lines += [
            "TDIU ELIGIBILITY:",
            "-" * 40,
            f"  {rating_result['tdiu_reason']}",
            "",
            "  TDIU (Total Disability based on Individual Unemployability) pays",
            "  at the 100% rate even if your combined rating is less than 100%.",
            "  If your disabilities prevent you from securing substantially",
            "  gainful employment, apply for TDIU on VA Form 21-8940.",
            "",
        ]

    if comp:
        lines += [
            "ESTIMATED MONTHLY COMPENSATION (2024 rates):",
            "-" * 40,
            f"  Combined Rating:        {comp['combined_rating']}%",
            f"  Base Monthly (no dep):  ${comp['base_monthly']:,.2f}",
            f"  Annual Estimate:        ${comp['annual_estimate']:,.2f}",
            f"",
            f"  {comp['disclaimer']}",
            "",
        ]

    lines += [
        "=" * 72,
        "NOTE: These are ESTIMATES based on your reported symptoms.",
        "Actual ratings are determined by VA adjudicators after C&P exams.",
        "=" * 72,
    ]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    os.chmod(path, 0o600)


def _write_pdf(claim_data: Dict, path: Path, ai_language: Optional[Dict], cp_prep: Optional[str]):
    """Generate a PDF version of the complete claim package."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    from reportlab.lib.enums import TA_CENTER, TA_LEFT

    doc = SimpleDocTemplate(
        str(path),
        pagesize=letter,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
        leftMargin=inch,
        rightMargin=inch,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("Title", parent=styles["Heading1"],
                                  fontSize=16, spaceAfter=12, textColor=colors.HexColor("#1a4a8c"))
    h2_style = ParagraphStyle("H2", parent=styles["Heading2"],
                               fontSize=13, spaceAfter=8, textColor=colors.HexColor("#1a4a8c"))
    body_style = ParagraphStyle("Body", parent=styles["Normal"],
                                 fontSize=10, spaceAfter=6, leading=14)
    highlight_style = ParagraphStyle("Highlight", parent=styles["Normal"],
                                      fontSize=10, spaceAfter=6, leading=14,
                                      backColor=colors.HexColor("#f0f7ff"),
                                      leftIndent=12, rightIndent=12, spaceBefore=4)
    warning_style = ParagraphStyle("Warning", parent=styles["Normal"],
                                    fontSize=10, spaceAfter=6, leading=14,
                                    textColor=colors.HexColor("#8b0000"))

    today = date.today()
    service = claim_data.get("service_info", {})
    elig = claim_data.get("eligibility", {})
    conditions = claim_data.get("conditions", [])
    rating_result = claim_data.get("rating_result", {})
    comp = claim_data.get("compensation_estimate", {})

    story = []

    # Cover Page
    story.append(Paragraph("VA BDD CLAIM PREPARATION PACKAGE", title_style))
    story.append(Paragraph(f"Prepared: {today}", body_style))
    story.append(Paragraph(
        "⚠ PROTECTED HEALTH INFORMATION — Handle with care. "
        "Share only with authorized VA personnel, VSOs, or treating physicians.",
        warning_style
    ))
    story.append(Spacer(1, 0.2 * inch))

    # Service Info Table
    story.append(Paragraph("Service Information", h2_style))
    svc_data = [
        ["Branch", service.get("branch", "N/A")],
        ["MOS/Rate/AFSC", service.get("mos", "N/A")],
        ["Rank", service.get("rank", "N/A")],
        ["Entry Date", service.get("entry_date", "N/A")],
        ["Separation Date", service.get("separation_date", "N/A")],
        ["Claim Type", elig.get("claim_type", "N/A").upper()],
    ]
    t = Table(svc_data, colWidths=[2 * inch, 4 * inch])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#1a4a8c")),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.white),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("PADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.2 * inch))

    # Eligibility
    if elig.get("exam_deadline"):
        story.append(Paragraph(
            f"⚠ C&P EXAM DEADLINE: {elig['exam_deadline']}",
            warning_style
        ))
    if elig.get("action"):
        story.append(Paragraph(f"Required Action: {elig['action']}", body_style))

    story.append(PageBreak())

    # Rating Summary
    story.append(Paragraph("Combined Rating Summary", h2_style))
    if rating_result:
        story.append(Paragraph(
            f"Estimated Combined Rating: {rating_result.get('combined_final', 0)}%",
            highlight_style
        ))
        if comp:
            story.append(Paragraph(
                f"Estimated Monthly Compensation: ${comp.get('base_monthly', 0):,.2f}/month "
                f"(${comp.get('annual_estimate', 0):,.2f}/year)",
                highlight_style
            ))
        if rating_result.get("tdiu_eligible"):
            story.append(Paragraph(f"TDIU Eligible: {rating_result['tdiu_reason']}", highlight_style))

    story.append(Spacer(1, 0.15 * inch))

    # Conditions
    story.append(Paragraph("Conditions Claimed & 526EZ Language", h2_style))
    for i, cond in enumerate(conditions, 1):
        story.append(Paragraph(f"{i}. {cond['condition_name']} — {cond['estimated_rating']}%", h2_style))
        story.append(Paragraph(
            f"DC: {cond['diagnostic_code']} | {cond.get('cfr_reference', '')}",
            body_style
        ))

        lang = (ai_language or {}).get(cond["condition_key"], {})
        if lang.get("form_language"):
            story.append(Paragraph("Claim Language (526EZ):", body_style))
            story.append(Paragraph(lang["form_language"], highlight_style))

        if lang.get("nexus_language"):
            story.append(Paragraph("Service Connection Statement:", body_style))
            story.append(Paragraph(lang["nexus_language"], highlight_style))

        story.append(Spacer(1, 0.1 * inch))

    story.append(PageBreak())

    # C&P Prep
    if cp_prep:
        story.append(Paragraph("C&P Exam Preparation Guide", h2_style))
        for line in cp_prep.split("\n"):
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.05 * inch))
            elif line.startswith("##"):
                story.append(Paragraph(line.replace("#", "").strip(), h2_style))
            elif line.startswith("**") and line.endswith("**"):
                story.append(Paragraph(f"<b>{line.replace('**', '').strip()}</b>", body_style))
            elif line.startswith("- ") or line.startswith("• "):
                story.append(Paragraph(f"• {line[2:]}", body_style))
            else:
                story.append(Paragraph(line, body_style))

    doc.build(story)
    os.chmod(path, 0o600)
