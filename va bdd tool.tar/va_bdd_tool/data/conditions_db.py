"""
38 CFR Part 4 - Schedule for Rating Disabilities
Complete conditions database with diagnostic codes, rating criteria,
DBQ examination questions, secondary condition flags, and C&P exam tips.
"""

CONDITIONS_DB = {

    # ─────────────────────────────────────────────
    # MUSCULOSKELETAL SYSTEM (DC 5000-5299)
    # ─────────────────────────────────────────────

    "cervical_strain": {
        "name": "Cervical Strain (Neck)",
        "diagnostic_code": "5237",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5237",
        "rating_criteria": {
            100: "Unfavorable ankylosis of the entire spine",
            50:  "Unfavorable ankylosis of entire cervical spine",
            30:  "Favorable ankylosis of entire cervical spine, or forward flexion of cervical spine 15° or less, or combined range of motion of cervical spine not more than 30°, or muscle spasm or guarding severe enough to result in an abnormal gait or abnormal spinal contour",
            20:  "Forward flexion of cervical spine greater than 15° but not greater than 30°, or combined range of motion of cervical spine not greater than 120°, or muscle spasm, guarding, or localized tenderness not allowing full range of motion, or vertebral body fracture with loss of 50 percent or more of the height",
            10:  "Forward flexion of cervical spine greater than 30° but not greater than 40°, or combined range of motion of cervical spine greater than 120° but not greater than 170°, or muscle spasm, guarding, or localized tenderness not allowing full range of motion, or paragraph (b) applies but is not of sufficient severity to warrant the 20 percent rating",
            0:   "Forward flexion greater than 40°, or combined range of motion greater than 170°, or with muscle spasm, guarding, or localized tenderness only",
        },
        "key_measurements": [
            "Forward flexion (normal: 45°)",
            "Extension (normal: 45°)",
            "Left lateral flexion (normal: 45°)",
            "Right lateral flexion (normal: 45°)",
            "Left rotation (normal: 80°)",
            "Right rotation (normal: 80°)",
        ],
        "dbq_questions": [
            "What is the forward flexion of your cervical spine (looking down)?",
            "Do you have muscle spasms in your neck?",
            "Do you have guarding — stiffness that limits how you move your neck?",
            "Does the pain radiate into your shoulders, arms, or hands?",
            "Does your neck condition affect your ability to work or perform daily activities?",
            "Have you received any imaging (X-ray, MRI) for your neck?",
            "Do you have any neurological symptoms — numbness, tingling, weakness in arms?",
        ],
        "secondary_conditions": [
            "thoracic_strain",
            "headaches_migraines",
            "peripheral_neuropathy",
            "sleep_impairment",
            "depression",
        ],
        "exam_tips": [
            "Be measured on your WORST day — not an average day.",
            "Report all radicular symptoms (shooting pain, numbness, tingling) separately.",
            "Bring your STRs (Service Treatment Records) showing neck complaints during service.",
            "Mention how the condition affects your work — specifically if you cannot look up, down, or turn for extended periods.",
            "If you have muscle spasms, make sure the examiner documents them — they can push a rating to the next tier.",
        ],
        "nexus_tips": [
            "Your nexus letter should note any in-service incidents (vehicle accidents, heavy lifting, parachute jumps, body armor wear).",
            "Chronic neck pain following a documented in-service fall, motor vehicle accident, or repetitive strain qualifies.",
        ],
    },

    "lumbosacral_strain": {
        "name": "Lumbosacral Strain (Lower Back)",
        "diagnostic_code": "5237",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5237",
        "rating_criteria": {
            100: "Unfavorable ankylosis of the entire spine",
            50:  "Unfavorable ankylosis of entire thoracolumbar spine",
            40:  "Unfavorable ankylosis of thoracolumbar spine",
            20:  "Forward flexion of the thoracolumbar spine 30° or less, or favorable ankylosis of the entire thoracolumbar spine",
            10:  "Forward flexion of the thoracolumbar spine greater than 30° but not greater than 60°, or combined range of motion of the thoracolumbar spine not greater than 120°, or muscle spasm or guarding severe enough to result in an abnormal gait or abnormal spinal contour such as scoliosis, reversed lordosis, or abnormal kyphosis",
            0:   "Forward flexion of the thoracolumbar spine greater than 60°, or combined range of motion of the thoracolumbar spine greater than 120°, or muscle spasm, guarding, or localized tenderness not resulting in abnormal gait or abnormal spinal contour, or vertebral body fracture with loss of 50 percent or more of the height",
        },
        "key_measurements": [
            "Forward flexion (normal: 90°)",
            "Extension (normal: 30°)",
            "Left lateral flexion (normal: 30°)",
            "Right lateral flexion (normal: 30°)",
            "Left rotation (normal: 30°)",
            "Right rotation (normal: 30°)",
        ],
        "dbq_questions": [
            "What is the forward flexion of your lumbar spine — how far can you bend forward?",
            "Do you have muscle spasms in your lower back?",
            "Do you have an abnormal gait (limping or altered walk) because of your back?",
            "Does pain radiate into your buttocks, legs, or feet (sciatica)?",
            "Do you have intervertebral disc disease, herniated disc, or degenerative disc disease?",
            "How does the condition affect your daily life — standing, sitting, sleeping?",
            "Do you have bladder or bowel problems associated with your back?",
        ],
        "secondary_conditions": [
            "hip_condition",
            "knee_condition_left",
            "knee_condition_right",
            "peripheral_neuropathy",
            "erectile_dysfunction",
            "sleep_impairment",
            "depression",
            "anxiety",
        ],
        "exam_tips": [
            "Flare-ups: Tell the examiner what your range of motion is DURING a flare — this must be documented separately under 38 CFR § 4.59.",
            "Painful motion: Under § 4.59, even painful motion at normal range can be rated.",
            "Muscle spasms that cause abnormal gait can qualify for a 10% rating by themselves.",
            "Do NOT stretch or do exercises before your C&P exam.",
            "Mention every daily activity affected: bending to tie shoes, sitting for more than 20 minutes, lifting.",
            "If you have radiating leg pain, this should be rated separately as sciatic nerve (DC 8520).",
        ],
        "nexus_tips": [
            "Document the specific in-service cause: ruck marching, heavy lifting, vehicle accidents, parachute landings, body armor wear over time.",
            "Army/Marine infantry, combat engineers, and airborne veterans have strong presumptive arguments for back injury.",
        ],
    },

    "knee_condition_left": {
        "name": "Left Knee Condition",
        "diagnostic_code": "5260",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5255–5263",
        "rating_criteria": {
            30: "Slight instability: 10–20° (or in a presumptive/favorable direction), OR limitation of extension to 20° or more",
            20: "Moderate instability: lateral movement of more than 1cm but less than total, OR limitation of extension to between 11° and 20°",
            10: "Slight instability: lateral movement to 1 cm, OR limitation of extension to between 6° and 10°, OR limitation of flexion to 30° or more",
            0:  "Objective evidence without swelling or instability, OR limitation of extension to less than 6°, OR limitation of flexion less than 30°",
        },
        "key_measurements": [
            "Flexion (normal: 0–140°)",
            "Extension (normal: 0°)",
            "Lateral stability (laxity in mm)",
            "Anterior-posterior stability",
            "Meniscal tenderness",
            "Crepitus (grinding/popping)",
        ],
        "dbq_questions": [
            "What is the range of flexion and extension in your left knee?",
            "Does your knee give way or feel unstable when walking or climbing stairs?",
            "Do you have locking, buckling, or popping of the knee?",
            "Do you have swelling or effusion in the knee?",
            "Have you had any surgery on this knee (meniscus, ACL, etc.)?",
            "Does the pain affect your ability to stand for extended periods, kneel, or climb?",
            "Do you have pain on motion (even at the beginning of movement)?",
        ],
        "secondary_conditions": [
            "hip_condition",
            "lumbosacral_strain",
            "ankle_condition_left",
            "sleep_impairment",
            "depression",
        ],
        "bilateral_pair": "knee_condition_right",
        "exam_tips": [
            "Request bilateral ratings if BOTH knees are affected — the bilateral factor adds 10% to the combined bilateral value.",
            "Pain on motion at the BEGINNING of movement can qualify for a rating even if full range is preserved.",
            "Crepitus documented alone can support at least a 10% rating.",
            "Instability and limitation of flexion are rated separately under different DCs — make sure BOTH are evaluated.",
            "If you have had surgery, request a convalescent rating (38 CFR § 4.30) for the surgical period.",
        ],
        "nexus_tips": [
            "Document in-service incidents: injury during PT, field training, jumping from vehicles, parachute landings.",
            "Overuse from ruck marching, extended patrols, or frequent stair climbing in boots qualifies.",
        ],
    },

    "knee_condition_right": {
        "name": "Right Knee Condition",
        "diagnostic_code": "5260",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5255–5263",
        "rating_criteria": {
            30: "Limitation of extension to 20° or more, OR significant instability",
            20: "Limitation of extension to between 11° and 20°, OR moderate instability",
            10: "Limitation of extension to between 6° and 10°, OR limitation of flexion to 30° or more, OR slight instability",
            0:  "Objective evidence without swelling or instability",
        },
        "key_measurements": [
            "Flexion (normal: 0–140°)",
            "Extension (normal: 0°)",
            "Lateral stability",
            "Crepitus",
        ],
        "dbq_questions": [
            "What is the range of flexion and extension in your right knee?",
            "Does your knee give way or feel unstable?",
            "Do you have swelling or effusion?",
            "Does the pain affect your ability to stand, kneel, or climb?",
        ],
        "secondary_conditions": [
            "hip_condition",
            "lumbosacral_strain",
            "ankle_condition_right",
        ],
        "bilateral_pair": "knee_condition_left",
        "exam_tips": [
            "Always evaluate alongside left knee — bilateral factor applies if both are service-connected.",
            "Painful motion at initial range of motion qualifies under § 4.59.",
        ],
        "nexus_tips": [
            "Same as left knee — document specific in-service cause.",
        ],
    },

    "shoulder_condition_left": {
        "name": "Left Shoulder Condition",
        "diagnostic_code": "5201",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5200–5203",
        "rating_criteria": {
            40: "Motion limited to 25° from the side (dominant) / 30° from side (non-dominant)",
            30: "Motion limited to 25° from side (non-dominant)",
            20: "Motion limited midway between side and shoulder level (to 45°), dominant / 30° non-dominant",
            10: "Motion limited to shoulder level (to 90°), dominant / midway non-dominant",
        },
        "key_measurements": [
            "Forward flexion (normal: 180°)",
            "Abduction (normal: 180°)",
            "Internal rotation",
            "External rotation",
        ],
        "dbq_questions": [
            "Can you raise your left arm above your head?",
            "What angle can you abduct (raise to the side) your left arm before pain stops you?",
            "Do you have rotator cuff damage, tears, or labral tears?",
            "Does the shoulder affect your ability to carry, lift, or reach?",
            "Do you have clicking, popping, or grinding in the shoulder?",
        ],
        "secondary_conditions": [
            "cervical_strain",
            "peripheral_neuropathy",
            "sleep_impairment",
        ],
        "bilateral_pair": "shoulder_condition_right",
        "exam_tips": [
            "Dominant vs. non-dominant matters — dominant arm is rated higher. Specify which is dominant.",
            "Measure abduction at point of pain onset, not maximum achievable.",
            "Rotator cuff tears and SLAP tears have their own DCs — ensure all are evaluated.",
        ],
        "nexus_tips": [
            "Repetitive overhead lifting, carrying heavy rucksacks, parachute operations, or a specific injury.",
        ],
    },

    "shoulder_condition_right": {
        "name": "Right Shoulder Condition",
        "diagnostic_code": "5201",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5200–5203",
        "rating_criteria": {
            40: "Motion limited to 25° from the side (dominant)",
            30: "Motion limited to 25° from side (non-dominant) or 30° dominant",
            20: "Motion limited to 45° dominant / non-dominant 30°",
            10: "Motion limited to 90° shoulder level",
        },
        "key_measurements": ["Forward flexion", "Abduction", "Internal rotation", "External rotation"],
        "dbq_questions": [
            "Can you raise your right arm above your head?",
            "What angle can you raise the right arm before pain stops you?",
            "Is the right arm your dominant arm?",
        ],
        "secondary_conditions": ["cervical_strain", "peripheral_neuropathy"],
        "bilateral_pair": "shoulder_condition_left",
        "exam_tips": ["Dominant arm rating is higher — confirm and document dominance."],
        "nexus_tips": ["Document specific in-service shoulder injury or repetitive use."],
    },

    "plantar_fasciitis_left": {
        "name": "Left Plantar Fasciitis / Pes Planus",
        "diagnostic_code": "5276",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5276–5284",
        "rating_criteria": {
            50: "Pronounced: marked pronation, extreme tenderness of plantar surfaces, marked inward displacement and weakness of angle, characteristic callous formation; and painful condition",
            30: "Severe: objective evidence of marked deformity (pronation, abduction, etc.), pain on manipulation and use, accentuated on use, indication of swelling on use, characteristic callous formation",
            10: "Moderate: weight-bearing line over or medial to great toe, inward bowing of tendo achilles, pain on manipulation and use, bilateral or unilateral",
            0:  "Mild: symptoms relieved by built-up shoe or arch support",
        },
        "key_measurements": ["Arch height", "Pronation degree", "Tenderness on palpation", "Callus formation"],
        "dbq_questions": [
            "Do you have pain on the bottom of your foot when standing or walking?",
            "Is the pain worse in the morning or after long periods of standing?",
            "Do you have calluses or deformity of the foot?",
            "Do orthotics or special shoes help — and are they required for you to walk?",
            "Does the condition affect your ability to stand for extended periods or march?",
        ],
        "secondary_conditions": ["knee_condition_left", "lumbosacral_strain", "ankle_condition_left"],
        "bilateral_pair": "plantar_fasciitis_right",
        "exam_tips": [
            "Do NOT wear orthotics to the C&P exam — they can reduce the severity of documented findings.",
            "Walk barefoot for the examiner so they can observe the pronation and gait deviation.",
            "Mention how long you can stand before pain forces you to sit.",
        ],
        "nexus_tips": [
            "Military boots, ruck marching, standing at parade rest, and running on hard surfaces all contribute.",
            "MOSs with high physical demand (infantry, MP, logistics) have strong claims.",
        ],
    },

    "plantar_fasciitis_right": {
        "name": "Right Plantar Fasciitis / Pes Planus",
        "diagnostic_code": "5276",
        "body_system": "musculoskeletal",
        "cfr_reference": "38 CFR § 4.71a, DC 5276",
        "rating_criteria": {
            50: "Pronounced: extreme tenderness, marked deformity, characteristic callous formation",
            30: "Severe: marked deformity, pain on manipulation and use",
            10: "Moderate: pain on use, inward bowing of tendo achilles",
            0:  "Mild: relieved by built-up shoe",
        },
        "key_measurements": ["Arch height", "Tenderness", "Callus formation"],
        "dbq_questions": [
            "Do you have pain on the bottom of your right foot?",
            "Do orthotics help — and are they required?",
        ],
        "secondary_conditions": ["knee_condition_right", "lumbosacral_strain"],
        "bilateral_pair": "plantar_fasciitis_left",
        "exam_tips": ["Same as left — do NOT wear orthotics to exam."],
        "nexus_tips": ["Document specific military duties that caused overuse."],
    },

    # ─────────────────────────────────────────────
    # MENTAL HEALTH (DC 9200-9440)
    # ─────────────────────────────────────────────

    "ptsd": {
        "name": "Post-Traumatic Stress Disorder (PTSD)",
        "diagnostic_code": "9411",
        "body_system": "mental_health",
        "cfr_reference": "38 CFR § 4.130, DC 9411",
        "rating_criteria": {
            100: "Total occupational and social impairment, due to such symptoms as: gross impairment in thought processes or communication; persistent delusions or hallucinations; grossly inappropriate behavior; persistent danger of hurting self or others; intermittent inability to perform activities of daily living; disorientation to time or place; memory loss for names of close relatives, own occupation, or own name",
            70:  "Occupational and social impairment with deficiencies in most areas, such as work, school, family relations, judgment, thinking, or mood, due to such symptoms as: suicidal ideation; obsessional rituals which interfere with routine activities; speech intermittently illogical, obscure, or irrelevant; near-continuous panic or depression affecting the ability to function independently, appropriately, and effectively; impaired impulse control (such as unprovoked irritability with periods of violence); spatial disorientation; neglect of personal appearance and hygiene; difficulty in adapting to stressful circumstances; inability to establish and maintain effective relationships",
            50:  "Occupational and social impairment with reduced reliability and productivity due to such symptoms as: flattened affect; circumstantial, circumlocutory, or stereotyped speech; panic attacks more than once a week; difficulty understanding complex commands; impairment of short- and long-term memory; impaired judgment; impaired abstract thinking; disturbances of motivation and mood; difficulty in establishing and maintaining effective work and social relationships",
            30:  "Occupational and social impairment with occasional decrease in work efficiency and intermittent periods of inability to perform occupational tasks (although generally functioning satisfactorily, with routine behavior, self-care, and conversation normal), due to such symptoms as: depressed mood, anxiety, suspiciousness, panic attacks (weekly or less often), chronic sleep impairment, mild memory loss",
            10:  "Occupational and social impairment due to mild or transient symptoms which decrease work efficiency and ability to perform occupational tasks only during periods of significant stress, or symptoms controlled by medication",
            0:   "A mental condition has been formally diagnosed, but symptoms are not severe enough either to interfere with occupational and social functioning or to require continuous medication",
        },
        "dbq_questions": [
            "Describe your stressor event(s) that occurred during military service.",
            "Do you have recurrent, intrusive memories, nightmares, or flashbacks of the event?",
            "Do you avoid people, places, or activities that remind you of the trauma?",
            "Do you experience hypervigilance — being constantly on guard, easily startled?",
            "Do you have sleep disturbances — difficulty falling asleep, staying asleep, or nightmares?",
            "Have you had thoughts of harming yourself or others?",
            "How has PTSD affected your work performance, relationships, and social life?",
            "Do you have panic attacks — and how often do they occur?",
            "Have you isolated yourself from friends or family?",
            "Are you currently in treatment — therapy, medication, or both?",
        ],
        "secondary_conditions": [
            "depression",
            "anxiety",
            "sleep_impairment",
            "substance_abuse",
            "tbi",
            "erectile_dysfunction",
            "hypertension",
            "irritable_bowel",
        ],
        "exam_tips": [
            "Describe your WORST symptoms — not your best day.",
            "Use specific examples: 'I have nightmares 4–5 nights per week', 'I had 3 panic attacks last month'.",
            "Describe how it affects your WORK: missed days, inability to concentrate, conflict with coworkers.",
            "Describe how it affects your RELATIONSHIPS: isolation, anger, inability to maintain friendships or marriage.",
            "If you take medication, note that symptoms are NOT fully controlled — just managed.",
            "Bring a buddy statement or spouse/family statement documenting behavior changes since service.",
            "If you have suicidal ideation (even passive), disclose this — it is a 70% symptom marker.",
        ],
        "nexus_tips": [
            "PTSD requires a documented in-service stressor — this can be combat, MST, witnessing death, or any life-threatening event.",
            "For combat veterans, the stressor is presumed credible if the veteran served in a combat zone.",
            "MST stressors do not require official documentation — your own statement plus corroborating evidence suffices.",
            "A private DBQ completed by your treating psychiatrist or psychologist carries significant weight.",
        ],
    },

    "depression": {
        "name": "Major Depressive Disorder",
        "diagnostic_code": "9434",
        "body_system": "mental_health",
        "cfr_reference": "38 CFR § 4.130, DC 9434",
        "rating_criteria": {
            100: "Total occupational and social impairment",
            70:  "Occupational and social impairment with deficiencies in most areas",
            50:  "Occupational and social impairment with reduced reliability and productivity",
            30:  "Occupational and social impairment with occasional decrease in work efficiency",
            10:  "Mild or transient symptoms controlled by medication or only present during stress",
            0:   "Formally diagnosed but not interfering with functioning",
        },
        "dbq_questions": [
            "How many days per week do you feel depressed or hopeless?",
            "Have you lost interest in activities you used to enjoy?",
            "Do you have difficulty concentrating or making decisions?",
            "Has your sleep or appetite changed significantly?",
            "Have you had thoughts of suicide or self-harm?",
            "How has depression affected your ability to work and maintain relationships?",
        ],
        "secondary_conditions": ["ptsd", "anxiety", "sleep_impairment", "chronic_pain"],
        "exam_tips": [
            "If depression is secondary to a physical condition (back pain, TBI, PTSD), claim it as a secondary condition.",
            "Describe ALL occupational impacts: missed work, inability to focus, conflicts.",
            "GAF (Global Assessment of Functioning) score below 50 generally supports 70%+.",
        ],
        "nexus_tips": [
            "Depression secondary to a service-connected condition (e.g., PTSD, chronic pain) is fully claimable.",
        ],
    },

    "anxiety": {
        "name": "Generalized Anxiety Disorder",
        "diagnostic_code": "9400",
        "body_system": "mental_health",
        "cfr_reference": "38 CFR § 4.130, DC 9400",
        "rating_criteria": {
            100: "Total occupational and social impairment",
            70:  "Occupational and social impairment with deficiencies in most areas — panic attacks, inability to function independently",
            50:  "Panic attacks more than once a week, difficulty with complex commands, reduced productivity",
            30:  "Panic attacks weekly or less, chronic sleep impairment, mild memory loss",
            10:  "Mild or transient symptoms controlled by medication",
            0:   "Formally diagnosed, not interfering with functioning",
        },
        "dbq_questions": [
            "Do you have panic attacks — how often and how severe?",
            "Do you experience excessive worry that you cannot control?",
            "Do you have physical symptoms: racing heart, sweating, trembling?",
            "Does anxiety prevent you from going to certain places or doing certain activities?",
            "How does anxiety affect your work and personal life?",
        ],
        "secondary_conditions": ["ptsd", "depression", "sleep_impairment", "hypertension"],
        "exam_tips": [
            "Frequency and severity of panic attacks is the key metric — track them before your exam.",
            "Note if anxiety has caused you to avoid situations (crowds, driving, public) — this is avoidance behavior.",
        ],
        "nexus_tips": [
            "Can be claimed directly or as secondary to PTSD, TBI, or chronic pain conditions.",
        ],
    },

    "tbi": {
        "name": "Traumatic Brain Injury (TBI)",
        "diagnostic_code": "8045",
        "body_system": "mental_health",
        "cfr_reference": "38 CFR § 4.124a, DC 8045",
        "rating_criteria": {
            100: "Severe TBI: one or more of the following — vegetative state, persistent disorientation, severe memory impairment, severe cognitive deficits",
            70:  "Moderately severe: severely impaired memory, judgment, thinking, mood; severe occupational/social impairment",
            50:  "Moderate: occupational/social impairment with reduced reliability; moderate memory, attention deficits",
            30:  "Mild: occasional decrease in work efficiency; mild memory loss, headaches, irritability",
            10:  "Mild or transient: symptoms only during stress or controlled by medication",
            0:   "Formally diagnosed but not interfering with functioning",
        },
        "dbq_questions": [
            "Were you exposed to a blast, explosion, or blow to the head during service?",
            "Did you lose consciousness — and for how long?",
            "Do you have persistent headaches — how frequent and severe?",
            "Do you have memory problems, difficulty concentrating, or confusion?",
            "Do you have changes in mood, personality, or behavior since the injury?",
            "Do you have sensitivity to light or sound?",
            "Do you have sleep disturbances related to the TBI?",
        ],
        "secondary_conditions": [
            "ptsd",
            "depression",
            "anxiety",
            "headaches_migraines",
            "sleep_impairment",
            "tinnitus",
            "hearing_loss",
        ],
        "exam_tips": [
            "TBI symptoms overlap with PTSD — both should be evaluated and rated separately.",
            "Headaches from TBI are rated separately as DC 8100 (Migraine/Headache).",
            "Cognitive deficits should be documented through neuropsychological testing.",
            "Note ALL symptoms even if mild — TBI is rated on the combined picture of all residuals.",
        ],
        "nexus_tips": [
            "Blast exposure in combat zones (IED, mortar, artillery) is a common qualifying event.",
            "Military records of LOC (loss of consciousness) or being evaluated for head injury support the claim.",
        ],
    },

    # ─────────────────────────────────────────────
    # AUDIOLOGY & VISION
    # ─────────────────────────────────────────────

    "tinnitus": {
        "name": "Tinnitus (Ringing in Ears)",
        "diagnostic_code": "6260",
        "body_system": "audiology",
        "cfr_reference": "38 CFR § 4.87, DC 6260",
        "rating_criteria": {
            10: "Tinnitus recurrent — rated as a single disability whether the condition is unilateral or bilateral. 10% is the maximum schedular rating.",
        },
        "dbq_questions": [
            "Do you have constant or intermittent ringing, buzzing, or hissing in your ears?",
            "Is it in one or both ears?",
            "How does tinnitus affect your sleep, concentration, or daily activities?",
            "Was noise exposure (gunfire, explosions, aircraft, machinery) part of your service?",
        ],
        "secondary_conditions": [
            "hearing_loss",
            "sleep_impairment",
            "depression",
            "anxiety",
        ],
        "exam_tips": [
            "Tinnitus is limited to 10% but is one of the most commonly granted claims — do not skip it.",
            "Bilateral tinnitus is still rated at 10% total.",
            "It combines with hearing loss for a higher total — claim both together.",
        ],
        "nexus_tips": [
            "Weapons qualification, aircraft proximity, combat, demolitions, or industrial noise during service.",
            "MOS-based noise exposure is well-documented — infantry, armor, aviation, artillery, and engineers all qualify.",
        ],
    },

    "hearing_loss": {
        "name": "Sensorineural Hearing Loss",
        "diagnostic_code": "6100",
        "body_system": "audiology",
        "cfr_reference": "38 CFR § 4.85–4.87, DC 6100",
        "rating_criteria": {
            100: "SX speech discrimination + Roman numeral combination per 38 CFR § 4.85 Table VI",
            80:  "Per Table VI — severe impairment",
            60:  "Per Table VI — marked impairment",
            40:  "Per Table VI — moderate impairment",
            20:  "Per Table VI — mild to moderate impairment",
            10:  "Per Table VI — mild impairment in both ears",
            0:   "Puretone average and speech discrimination within normal limits",
        },
        "dbq_questions": [
            "Do you have difficulty understanding speech in noisy environments?",
            "Do you need to ask people to repeat themselves frequently?",
            "Have you had a formal audiological evaluation — and what were the results?",
            "Do you use hearing aids?",
            "Was noise a significant part of your military service (weapons, aircraft, vehicles)?",
        ],
        "secondary_conditions": ["tinnitus", "depression", "anxiety"],
        "exam_tips": [
            "The audiologist will conduct a puretone average and speech discrimination test — both are needed.",
            "Hearing aids may HELP but do not disqualify you — the rating is based on the UNAIDED audiogram.",
            "Request the examiner document your WORST ear results.",
        ],
        "nexus_tips": [
            "In-service audiogram showing normal hearing at entry, then degraded hearing at separation, is strong nexus.",
            "MOS/specialty codes with known noise exposure are typically sufficient for nexus.",
        ],
    },

    # ─────────────────────────────────────────────
    # RESPIRATORY SYSTEM
    # ─────────────────────────────────────────────

    "sleep_apnea": {
        "name": "Obstructive Sleep Apnea",
        "diagnostic_code": "6847",
        "body_system": "respiratory",
        "cfr_reference": "38 CFR § 4.97, DC 6847",
        "rating_criteria": {
            100: "Chronic respiratory failure with carbon dioxide retention, or cor pulmonale, or requires tracheostomy",
            50:  "Requires use of breathing assistance device such as CPAP machine",
            30:  "Persistent daytime hypersomnolence",
            0:   "Asymptomatic but with documented sleep disorder breathing",
        },
        "dbq_questions": [
            "Have you been diagnosed with sleep apnea via a sleep study (polysomnography)?",
            "Do you use a CPAP, BiPAP, or other breathing device at night?",
            "Do you have excessive daytime sleepiness despite using the device?",
            "Do you snore loudly or stop breathing during sleep (as reported by others)?",
            "Did your sleep problems begin or worsen during military service?",
        ],
        "secondary_conditions": [
            "hypertension",
            "depression",
            "ptsd",
            "heart_condition",
        ],
        "exam_tips": [
            "A CPAP prescription alone qualifies for 50% — this is one of the most straightforward claims.",
            "Make sure your sleep study results are in your records.",
            "If daytime sleepiness persists DESPITE CPAP, document this — it supports 50% even with device use.",
        ],
        "nexus_tips": [
            "Sleep apnea as secondary to PTSD, TBI, or other mental health conditions is a well-established connection.",
            "Weight gain during service that contributed to sleep apnea can support a direct nexus.",
        ],
    },

    # ─────────────────────────────────────────────
    # CARDIOVASCULAR SYSTEM
    # ─────────────────────────────────────────────

    "hypertension": {
        "name": "Hypertension (High Blood Pressure)",
        "diagnostic_code": "7101",
        "body_system": "cardiovascular",
        "cfr_reference": "38 CFR § 4.104, DC 7101",
        "rating_criteria": {
            60: "Diastolic pressure predominantly 130 or more",
            40: "Diastolic pressure predominantly 120 or more",
            20: "Diastolic pressure predominantly 110 or more, or systolic pressure predominantly 200 or more",
            10: "Diastolic pressure predominantly 100 or more, or systolic pressure predominantly 160 or more, or minimum evaluation for an individual with a history of diastolic pressure predominantly 100 or more who requires continuous medication for control",
        },
        "dbq_questions": [
            "What is your typical blood pressure reading (systolic/diastolic)?",
            "Are you on medication to control your blood pressure?",
            "How long have you had hypertension?",
            "Were elevated blood pressure readings documented during your service?",
            "Do you have any end-organ damage (kidney disease, heart disease, eye problems)?",
        ],
        "secondary_conditions": ["ptsd", "sleep_apnea", "anxiety", "heart_condition", "kidney_disease"],
        "exam_tips": [
            "Multiple readings are taken — do NOT take blood pressure medication the morning of your exam (consult your doctor first).",
            "Bring records of your highest documented readings.",
            "If you require medication for control, that alone qualifies for 10% even if readings are now normal.",
        ],
        "nexus_tips": [
            "Hypertension secondary to PTSD or anxiety is a well-established secondary condition.",
            "In-service readings showing elevated BP are strong direct nexus evidence.",
        ],
    },

    # ─────────────────────────────────────────────
    # SKIN
    # ─────────────────────────────────────────────

    "dermatitis": {
        "name": "Dermatitis / Eczema",
        "diagnostic_code": "7806",
        "body_system": "skin",
        "cfr_reference": "38 CFR § 4.118, DC 7806",
        "rating_criteria": {
            60: "More than 40 percent of the entire body or more than 40 percent of exposed areas affected, or constant or near-constant systemic therapy such as corticosteroids or other immunosuppressive drugs required during the past 12-month period",
            30: "20 to 40 percent of the entire body or 20 to 40 percent of exposed areas affected, or systemic therapy such as corticosteroids required for a total duration of 6 weeks or more, but not constantly, during the past 12-month period",
            10: "At least 5 percent, but less than 20 percent, of the entire body, or at least 5 percent, but less than 20 percent, of exposed areas affected, or intermittent systemic therapy such as corticosteroids required for a total duration of less than 6 weeks during the past 12-month period",
            0:  "Less than 5 percent of the entire body or less than 5 percent of exposed areas affected, and; no more than topical therapy required during the past 12-month period",
        },
        "dbq_questions": [
            "What percentage of your body is affected by the skin condition?",
            "Do you require systemic medication (oral steroids, immunosuppressants) to control it?",
            "How often do you have flare-ups?",
            "Do you use only topical treatments, or systemic (pill/injection) treatments?",
            "Were you exposed to chemicals, environmental hazards, or burn pits during service?",
        ],
        "secondary_conditions": [],
        "exam_tips": [
            "Do NOT apply topical treatments on the day of the exam — show the condition at its natural state.",
            "The percentage of body surface affected is key — measure and document this before your exam.",
            "Systemic medication requirement is the biggest rating driver.",
        ],
        "nexus_tips": [
            "Burn pit exposure, chemical exposure, or tropical deployment are common nexus sources.",
            "PACT Act (2022) creates presumptives for many skin conditions from burn pit exposure.",
        ],
    },

    # ─────────────────────────────────────────────
    # GENITOURINARY / OTHER
    # ─────────────────────────────────────────────

    "erectile_dysfunction": {
        "name": "Erectile Dysfunction",
        "diagnostic_code": "7522",
        "body_system": "genitourinary",
        "cfr_reference": "38 CFR § 4.115b, DC 7522",
        "rating_criteria": {
            0:  "Rated as 0% with a Special Monthly Compensation (SMC) entitlement at the (k) level — equivalent in value to approximately $115–$120/month additional",
        },
        "dbq_questions": [
            "Have you been diagnosed with erectile dysfunction by a physician?",
            "Do you take medication (Viagra, Cialis, etc.) or use devices to manage it?",
            "Has this condition been associated with your service-connected condition (PTSD, spinal injury, prostate condition)?",
        ],
        "secondary_conditions": ["ptsd", "depression", "lumbosacral_strain", "hypertension"],
        "exam_tips": [
            "Erectile dysfunction is rated 0% but triggers Special Monthly Compensation (SMC-k).",
            "SMC-k adds significant monthly compensation even at 0% — do NOT skip this claim.",
            "Claim as secondary to PTSD, spinal cord injury, prostate condition, or medication side effects.",
        ],
        "nexus_tips": [
            "Secondary to PTSD, lumbar spine conditions with nerve involvement, or medication side effects.",
        ],
    },

    "sleep_impairment": {
        "name": "Sleep Impairment (Secondary Condition)",
        "diagnostic_code": "None",
        "body_system": "mental_health",
        "cfr_reference": "38 CFR § 4.130",
        "rating_criteria": {
            0: "Sleep impairment is typically rated as a symptom within the mental health general rating formula rather than a standalone DC. Document as part of PTSD, depression, or TBI.",
        },
        "dbq_questions": [
            "How many hours of sleep do you get per night?",
            "How often do you wake during the night?",
            "Do nightmares or hypervigilance prevent sleep?",
            "Does poor sleep affect your daytime functioning?",
        ],
        "secondary_conditions": [],
        "exam_tips": [
            "Sleep impairment boosts the rating for PTSD, depression, and TBI — document it thoroughly within those claims.",
            "If sleep apnea is the primary issue, file DC 6847 separately for a 50% rating.",
        ],
        "nexus_tips": [],
    },

    "headaches_migraines": {
        "name": "Migraine Headaches",
        "diagnostic_code": "8100",
        "body_system": "neurological",
        "cfr_reference": "38 CFR § 4.124a, DC 8100",
        "rating_criteria": {
            50: "With very frequent completely prostrating and prolonged attacks productive of severe economic inadaptability",
            30: "With characteristic prostrating attacks occurring on an average once a month over the last several months",
            10: "With characteristic prostrating attacks averaging one in 2 months over the last several months",
            0:  "With less frequent attacks",
        },
        "dbq_questions": [
            "How frequently do you have headaches — per week or per month?",
            "Are the headaches prostrating — do they force you to stop all activity and lie down?",
            "How long does each headache last?",
            "Have headaches caused you to miss work or fail to perform occupational tasks?",
            "Are they associated with nausea, light/sound sensitivity, or visual aura?",
            "Are headaches related to a TBI, cervical strain, or other service-connected condition?",
        ],
        "secondary_conditions": ["tbi", "cervical_strain", "ptsd", "depression"],
        "exam_tips": [
            "Frequency and prostration are everything — document EVERY headache in a log before your exam.",
            "Prostrating means you had to stop ALL activity — lying down, unable to work or function.",
            "If migraines are caused by your TBI or neck condition, claim as secondary.",
        ],
        "nexus_tips": [
            "TBI from blast exposure is a well-established nexus for migraines.",
            "Cervical strain causing tension headaches can also support nexus.",
        ],
    },

    "peripheral_neuropathy": {
        "name": "Peripheral Neuropathy",
        "diagnostic_code": "8515",
        "body_system": "neurological",
        "cfr_reference": "38 CFR § 4.124a, DC 8510–8730",
        "rating_criteria": {
            40: "Complete paralysis of the nerve",
            20: "Incomplete paralysis of the nerve, moderate",
            10: "Incomplete paralysis of the nerve, mild",
        },
        "dbq_questions": [
            "Do you have numbness, tingling, or burning in your hands or feet?",
            "Is the sensation loss constant or intermittent?",
            "Do you have weakness in the affected limbs?",
            "Has the neuropathy affected your ability to grip, walk, or perform fine motor tasks?",
            "Is the neuropathy associated with your back condition, diabetes, or other condition?",
        ],
        "secondary_conditions": ["lumbosacral_strain", "cervical_strain", "diabetes"],
        "exam_tips": [
            "Peripheral neuropathy is rated per nerve and per limb — each affected nerve can be a separate rating.",
            "If caused by your back condition, claim as secondary.",
        ],
        "nexus_tips": [
            "Commonly secondary to lumbar or cervical radiculopathy.",
            "Agent Orange exposure creates presumptive peripheral neuropathy for qualifying veterans.",
        ],
    },

    "irritable_bowel": {
        "name": "Irritable Bowel Syndrome (IBS)",
        "diagnostic_code": "7319",
        "body_system": "digestive",
        "cfr_reference": "38 CFR § 4.114, DC 7319",
        "rating_criteria": {
            30: "Severe; diarrhea, or alternating diarrhea and constipation, with more or less constant abdominal distress",
            10: "Moderate; frequent episodes of bowel disturbance with abdominal distress",
            0:  "Mild; disturbances of bowel function with occasional episodes of abdominal distress",
        },
        "dbq_questions": [
            "How frequent are episodes of diarrhea or constipation?",
            "Do you have constant or near-constant abdominal pain or cramping?",
            "Has IBS caused you to miss work or avoid social situations?",
            "Is the condition related to your PTSD, anxiety, or another service-connected condition?",
        ],
        "secondary_conditions": ["ptsd", "anxiety", "depression"],
        "exam_tips": [
            "Frequency and constancy of symptoms drive the rating — document daily symptom logs.",
            "Secondary to PTSD or anxiety is a strong claim basis.",
        ],
        "nexus_tips": [
            "IBS secondary to PTSD is well-recognized — cite the gut-brain axis connection.",
        ],
    },
}


# ─────────────────────────────────────────────────────
# BODY SYSTEM MENU STRUCTURE
# ─────────────────────────────────────────────────────

BODY_SYSTEMS = {
    "musculoskeletal": {
        "label": "Musculoskeletal System (Back, Knees, Shoulders, Feet, etc.)",
        "conditions": [
            "lumbosacral_strain",
            "cervical_strain",
            "knee_condition_left",
            "knee_condition_right",
            "shoulder_condition_left",
            "shoulder_condition_right",
            "plantar_fasciitis_left",
            "plantar_fasciitis_right",
        ],
    },
    "mental_health": {
        "label": "Mental Health (PTSD, Depression, Anxiety, TBI)",
        "conditions": [
            "ptsd",
            "depression",
            "anxiety",
            "tbi",
            "sleep_impairment",
        ],
    },
    "audiology": {
        "label": "Audiology & Vision (Hearing Loss, Tinnitus)",
        "conditions": [
            "tinnitus",
            "hearing_loss",
        ],
    },
    "respiratory": {
        "label": "Respiratory System (Sleep Apnea, Asthma)",
        "conditions": [
            "sleep_apnea",
        ],
    },
    "cardiovascular": {
        "label": "Cardiovascular System (Hypertension, Heart Conditions)",
        "conditions": [
            "hypertension",
        ],
    },
    "skin": {
        "label": "Skin Conditions (Dermatitis, Burn Pit Related)",
        "conditions": [
            "dermatitis",
        ],
    },
    "genitourinary": {
        "label": "Genitourinary System",
        "conditions": [
            "erectile_dysfunction",
        ],
    },
    "neurological": {
        "label": "Neurological (Migraines, Peripheral Neuropathy)",
        "conditions": [
            "headaches_migraines",
            "peripheral_neuropathy",
        ],
    },
    "digestive": {
        "label": "Digestive System (IBS, GERD)",
        "conditions": [
            "irritable_bowel",
        ],
    },
}


# ─────────────────────────────────────────────────────
# SECONDARY CONDITION MAP
# ─────────────────────────────────────────────────────

SECONDARY_PROMPTS = {
    "lumbosacral_strain": [
        ("hip_condition", "Lower back conditions commonly cause hip misalignment. Do you have hip pain?"),
        ("knee_condition_left", "Back problems can alter gait and stress the knees. Do you have left knee pain?"),
        ("knee_condition_right", "Back problems can alter gait and stress the knees. Do you have right knee pain?"),
        ("peripheral_neuropathy", "Lumbar spine conditions can compress nerves causing numbness/tingling in the legs. Do you have leg numbness?"),
        ("erectile_dysfunction", "Lumbar nerve compression can cause erectile dysfunction. Have you experienced this?"),
        ("depression", "Chronic pain frequently causes depression. Have you experienced persistent low mood?"),
        ("sleep_impairment", "Chronic pain disrupts sleep. Do you have significant sleep problems?"),
    ],
    "ptsd": [
        ("depression", "PTSD and depression commonly co-occur. Do you also experience persistent depression?"),
        ("anxiety", "Anxiety disorders frequently co-occur with PTSD. Do you have generalized anxiety?"),
        ("sleep_apnea", "PTSD disrupts sleep patterns and is linked to sleep apnea. Have you been evaluated?"),
        ("hypertension", "PTSD causes chronic stress responses linked to high blood pressure. Have you been diagnosed?"),
        ("irritable_bowel", "PTSD affects the gut-brain axis and can cause IBS. Do you have frequent bowel disturbances?"),
        ("erectile_dysfunction", "PTSD and its medications commonly cause erectile dysfunction. Is this a concern?"),
        ("tinnitus", "Combat stress and hypervigilance often accompany tinnitus. Do you have ringing in your ears?"),
    ],
    "tbi": [
        ("ptsd", "TBI and PTSD frequently co-occur in combat veterans. Have you been evaluated for PTSD?"),
        ("headaches_migraines", "TBI is a primary cause of persistent migraines. Do you have frequent headaches?"),
        ("sleep_impairment", "TBI commonly disrupts sleep architecture. Do you have significant sleep problems?"),
        ("depression", "TBI frequently causes depression. Have you experienced persistent low mood?"),
        ("tinnitus", "Blast-related TBI commonly causes tinnitus. Do you have ringing in your ears?"),
        ("hearing_loss", "Blast TBI frequently causes hearing damage. Have you had your hearing tested?"),
    ],
    "knee_condition_left": [
        ("lumbosacral_strain", "Knee conditions alter gait and can cause lower back strain. Do you have back pain?"),
        ("hip_condition", "Knee problems shift weight to the hip. Do you have hip pain on the same side?"),
    ],
    "sleep_apnea": [
        ("hypertension", "Sleep apnea is a major contributor to hypertension. Have you been diagnosed with high blood pressure?"),
        ("depression", "Sleep apnea causes fatigue and depressive symptoms. Do you experience persistent low mood?"),
    ],
}
