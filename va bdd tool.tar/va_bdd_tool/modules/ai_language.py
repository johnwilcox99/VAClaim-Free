"""
AI Language Generation Module
Uses Claude API to generate optimized, 38 CFR-aligned language for:
  - VA Form 21-526EZ condition descriptions
  - Nexus letter frameworks
  - C&P exam preparation scripts
  - Secondary condition justifications

All generated language uses consistent terminology aligned with
VA rating criteria to maximize rating potential.
"""

import anthropic
import json
from typing import Dict, List, Optional
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.progress import Progress, SpinnerColumn, TextColumn
import questionary
from questionary import Style

STYLE = Style([
    ("qmark", "fg:cyan bold"),
    ("question", "bold"),
    ("answer", "fg:green bold"),
    ("pointer", "fg:cyan bold"),
    ("highlighted", "fg:cyan bold"),
])

console = Console()

SYSTEM_PROMPT = """You are an expert VA disability claims specialist with deep knowledge of:
- 38 CFR Part 4 (Schedule for Rating Disabilities)
- VA Diagnostic Codes and rating criteria
- DBQ (Disability Benefits Questionnaire) frameworks
- Benefits Delivery at Discharge (BDD) requirements
- The "benefit of the doubt" standard (38 CFR § 4.3)
- Nexus letter requirements and service connection standards

Your role is to help veterans prepare their claims with language that:
1. Uses precise, consistent terminology aligned with 38 CFR rating criteria
2. Accurately describes the veteran's condition at its WORST/most symptomatic
3. Connects symptoms to specific rating thresholds in VA's Schedule
4. Establishes clear in-service nexus (cause-and-effect) where applicable
5. Identifies secondary condition opportunities

CRITICAL PRINCIPLES:
- Never fabricate or exaggerate symptoms — only describe what the veteran reports
- Always apply "benefit of the doubt" (§ 4.3) when symptoms are borderline between ratings
- Use the exact language from 38 CFR rating criteria where applicable (examiners recognize it)
- Every claim statement must be truthful and based on the veteran's actual experience
- Format language for VA Form 21-526EZ's "nature and extent of condition" fields

You MUST format all responses in valid JSON unless explicitly told otherwise."""


def generate_condition_description(
    condition_name: str,
    diagnostic_code: str,
    cfr_reference: str,
    symptoms: Dict,
    rating_criteria: Dict,
    service_info: Dict,
    target_rating: Optional[int] = None,
) -> Dict:
    """
    Generate optimized VA Form 21-526EZ language for a specific condition.

    Returns dict with:
        - form_language: Ready-to-use 526EZ description
        - rating_justification: Why this rating tier is appropriate
        - key_phrases: Critical phrases that align with VA rating criteria
        - suggested_edits: Areas where veteran can personalize
    """
    client = anthropic.Anthropic()

    prompt = f"""Generate optimized VA Form 21-526EZ claim language for this veteran's condition.

CONDITION: {condition_name}
DIAGNOSTIC CODE: {diagnostic_code}
CFR REFERENCE: {cfr_reference}
TARGET RATING: {target_rating if target_rating else 'Maximum supportable by reported symptoms'}

VETERAN'S REPORTED SYMPTOMS:
{json.dumps(symptoms, indent=2)}

SERVICE INFORMATION:
{json.dumps(service_info, indent=2)}

38 CFR RATING CRITERIA FOR THIS CONDITION:
{json.dumps(rating_criteria, indent=2)}

Generate the following in JSON format:
{{
    "form_language": "Complete, ready-to-use description for VA Form 21-526EZ (2-4 sentences, precise medical language)",
    "rating_justification": "Explanation of which rating tier this supports and why (1-2 sentences)",
    "target_rating_percentage": <integer — the highest rating these symptoms can support>,
    "key_phrases": ["array", "of", "critical 38 CFR-aligned phrases to include"],
    "nexus_language": "One sentence establishing service connection (cause-effect from service to condition)",
    "suggested_personalization": "Instruction for veteran on how to make this language their own and add specific details",
    "warning": "Any symptoms the veteran should be sure to document before C&P exam"
}}

IMPORTANT: The form_language must use precise terms from the 38 CFR rating criteria (e.g., 'forward flexion limited to approximately X degrees', 'prostrating attacks', 'deficiencies in most areas').
Do not include symptoms the veteran did not report. Apply benefit of the doubt (§ 4.3) at borderline thresholds."""

    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[cyan]Generating optimized claim language..."),
        transient=True,
    ) as progress:
        progress.add_task("generate", total=None)
        response = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1200,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}]
        )

    raw = response.content[0].text.strip()
    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip()

    try:
        return json.loads(raw)
    except Exception:
        return {
            "form_language": raw,
            "rating_justification": "Review and adjust as needed.",
            "target_rating_percentage": target_rating or 0,
            "key_phrases": [],
            "nexus_language": "",
            "suggested_personalization": "Review and personalize with your specific details.",
            "warning": "",
        }


def generate_nexus_letter_framework(
    condition_name: str,
    diagnostic_code: str,
    service_info: Dict,
    in_service_events: List[str],
    is_secondary: bool = False,
    primary_condition: Optional[str] = None,
) -> str:
    """
    Generate a nexus letter framework for a treating physician to complete.
    """
    client = anthropic.Anthropic()

    secondary_context = ""
    if is_secondary and primary_condition:
        secondary_context = f"""
This is a SECONDARY condition claim:
- Primary service-connected condition: {primary_condition}
- The nexus letter should establish that {condition_name} was CAUSED OR AGGRAVATED BY the primary condition.
- Cite the medical literature/mechanism linking these conditions."""

    prompt = f"""Generate a nexus letter FRAMEWORK for a treating physician to complete and sign.

VETERAN'S CONDITION: {condition_name} (DC {diagnostic_code})
SERVICE INFORMATION: {json.dumps(service_info, indent=2)}
IN-SERVICE EVENTS/EXPOSURES: {'; '.join(in_service_events) if in_service_events else 'As described by veteran'}
{secondary_context}

Generate a complete nexus letter framework (NOT JSON — plain professional medical letter format) that:
1. Includes the required nexus opinion standard: "at least as likely as not" (50% probability threshold)
2. References the specific in-service events or conditions
3. Includes placeholders [IN BRACKETS] where the physician fills in their specific findings
4. Cites the mechanism of injury/causation
5. Is formatted as a professional medical letter ready for physician signature

The letter must use the legally required language: "It is my medical opinion that [condition] is at least as likely as not related to the veteran's military service..."

Keep it to 1 page (approximately 350-450 words). Professional, factual, and persuasive."""

    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[cyan]Generating nexus letter framework..."),
        transient=True,
    ) as progress:
        progress.add_task("generate", total=None)
        response = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=800,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}]
        )

    return response.content[0].text.strip()


def generate_cp_exam_prep(
    conditions: List[Dict],
    service_info: Dict,
) -> str:
    """
    Generate a C&P exam preparation guide for the veteran.
    """
    client = anthropic.Anthropic()

    conditions_summary = "\n".join([
        f"- {c['name']} (DC {c['diagnostic_code']}): Target rating {c.get('target_rating', 'max')}%"
        for c in conditions
    ])

    prompt = f"""Generate a comprehensive C&P (Compensation & Pension) exam preparation guide for this veteran.

CONDITIONS BEING CLAIMED:
{conditions_summary}

SERVICE INFO: {json.dumps(service_info, indent=2)}

Create a practical, actionable prep guide (NOT JSON — formatted as readable sections) that covers:

1. BEFORE THE EXAM
   - What to bring (documents, records, buddy statements)
   - How to present symptoms (worst day, not average)
   - What NOT to do (don't minimize, don't wear orthotics, etc.)

2. DURING THE EXAM — for each condition:
   - Key symptoms to mention first
   - Exact measurements/severity to communicate
   - Questions the examiner will likely ask
   - Phrases from 38 CFR criteria to use naturally

3. COMMON MISTAKES TO AVOID
   - Under-reporting on bad exam days
   - Not mentioning secondary effects
   - Failing to mention how conditions affect work/daily life

4. YOUR RIGHTS
   - Right to bring a VSO representative
   - Right to request a new exam if unsatisfied
   - Right to submit a personal statement

Format with clear headers, bullet points, and BOLD the most critical points.
Use plain language the veteran can understand. Be encouraging and specific."""

    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[cyan]Generating C&P exam preparation guide..."),
        transient=True,
    ) as progress:
        progress.add_task("generate", total=None)
        response = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1500,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}]
        )

    return response.content[0].text.strip()


def interactive_language_review(
    label: str,
    generated_text: str,
    field_name: str = "description",
) -> str:
    """
    Present generated language to the veteran and allow them to accept,
    edit, or regenerate. Returns the final approved text.
    """
    console.print()
    console.print(Panel(
        f"[bold cyan]AI-Generated Language — {label}[/bold cyan]\n\n"
        "[dim]Review the language below. You can accept it, edit it, or request a revision.[/dim]",
        border_style="cyan"
    ))

    console.print(Panel(generated_text, title=f"📝 {field_name}", border_style="white", padding=(1, 2)))
    console.print()

    choice = questionary.select(
        "What would you like to do with this language?",
        choices=[
            "✅  Accept — use as written",
            "✏️   Edit — I'll modify it myself",
            "🔄  Regenerate — generate a different version",
            "⬛  Skip — do not include this",
        ],
        style=STYLE
    ).ask()

    if choice is None or "Skip" in choice:
        return ""

    if "Accept" in choice:
        return generated_text

    if "Edit" in choice:
        console.print("[dim]Type your edited version below. Press Enter twice when done.[/dim]")
        lines = []
        while True:
            line = input()
            if line == "" and lines and lines[-1] == "":
                break
            lines.append(line)
        return "\n".join(lines[:-1]).strip() or generated_text

    # Regenerate — caller handles this
    return "REGENERATE"
