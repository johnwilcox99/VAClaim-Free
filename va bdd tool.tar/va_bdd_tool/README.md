# VA BDD Claim Preparation Tool

A Python CLI application to help veterans prepare Benefits Delivery at Discharge (BDD)
disability claims with maximum rating potential under **38 CFR Part 4**.

---

## What This Tool Does

| Feature | Details |
|---------|---------|
| **BDD Eligibility Check** | Calculates whether you qualify (90–180 day window), filing deadlines, C&P exam deadlines |
| **Condition Intake** | Guided symptom interviews for all 38 CFR Part 4 body systems |
| **Secondary Conditions** | Flags conditions that can be claimed as secondary to primary conditions |
| **Combined Rating Calculator** | 38 CFR § 4.25 whole-person math + bilateral factor (§ 4.26) |
| **TDIU Screening** | Flags eligibility for Total Disability based on Individual Unemployability |
| **AI Language Generation** | Claude API generates 38 CFR-aligned claim language for 526EZ |
| **Nexus Letter Frameworks** | Ready-to-sign templates for treating physicians |
| **C&P Exam Prep Sheet** | Condition-by-condition exam preparation guide |
| **PDF Claim Package** | Complete printable document bundle |
| **Encrypted Local Storage** | All PII/PHI encrypted with AES via PBKDF2 — nothing leaves your computer |

---

## Setup

### Requirements
- Python 3.9 or higher
- An Anthropic API key (for AI language generation — optional but strongly recommended)
- ~50MB disk space

### Installation

```bash
# 1. Navigate to the tool directory
cd va_bdd_tool

# 2. Run setup verification (installs all dependencies)
python setup.py

# 3. Set your Anthropic API key (optional — for AI features)
# Mac / Linux:
export ANTHROPIC_API_KEY='your-key-here'

# Windows:
set ANTHROPIC_API_KEY=your-key-here

# 4. Launch the tool
python main.py
```

### Manual Dependency Install
```bash
pip install rich cryptography anthropic reportlab questionary python-dateutil
```

---

## Usage

### First Launch
1. The tool will ask where to store your encrypted data (default: `~/.va_bdd_tool/`)
2. You create a password — this encrypts all your claim data locally
3. **Write this password down** — there is no recovery mechanism by design

### Workflow
```
Main Menu
├── Start New Claim
│   ├── Step 1: BDD Eligibility Check
│   │   └── Branch, dates, separation timeline, deadlines
│   ├── Step 2: Condition Selection
│   │   ├── Select body systems (musculoskeletal, mental health, etc.)
│   │   └── Select specific conditions within each system
│   ├── Step 2a: Secondary Conditions
│   │   └── Prompted automatically based on primary conditions
│   ├── Step 3: Symptom Documentation
│   │   ├── Guided interview per condition
│   │   ├── Rating criteria displayed for reference
│   │   ├── Key measurements
│   │   ├── Functional impact
│   │   └── In-service nexus events
│   ├── Step 4: Rating Calculation
│   │   ├── Combined rating (38 CFR § 4.25)
│   │   ├── Bilateral factor (§ 4.26)
│   │   ├── TDIU screening (§ 4.16)
│   │   └── Monthly compensation estimate
│   ├── Step 5: AI Language Generation
│   │   ├── 526EZ claim language per condition
│   │   ├── Review / Edit / Regenerate interface
│   │   ├── Nexus letter frameworks
│   │   └── C&P exam preparation guide
│   └── Step 6: Document Generation
│       ├── VA_BDD_Claim_Summary.txt
│       ├── VA_526EZ_Language.txt
│       ├── CP_Exam_Prep_Sheet.txt
│       ├── Nexus_Letter_Frameworks.txt
│       ├── Rating_Calculation_Summary.txt
│       └── VA_BDD_Complete_Claim_Package.pdf
├── Resume Saved Claim
├── Rating Calculator (standalone)
├── Generate Output Documents
└── Settings
    ├── Export to plain text (for VSO)
    └── Clear all data
```

---

## Conditions Covered

### Musculoskeletal (38 CFR § 4.71a)
- Lumbosacral Strain (DC 5237) — Lower Back
- Cervical Strain (DC 5237) — Neck
- Knee Conditions (DC 5260) — Left/Right with bilateral factor
- Shoulder Conditions (DC 5201) — Left/Right with dominant arm rating
- Plantar Fasciitis / Pes Planus (DC 5276) — Left/Right

### Mental Health (38 CFR § 4.130)
- PTSD (DC 9411)
- Major Depressive Disorder (DC 9434)
- Generalized Anxiety Disorder (DC 9400)
- Traumatic Brain Injury (DC 8045)

### Audiology (38 CFR § 4.85–4.87)
- Tinnitus (DC 6260)
- Sensorineural Hearing Loss (DC 6100)

### Respiratory (38 CFR § 4.97)
- Obstructive Sleep Apnea (DC 6847)

### Cardiovascular (38 CFR § 4.104)
- Hypertension (DC 7101)

### Skin (38 CFR § 4.118)
- Dermatitis/Eczema (DC 7806)

### Genitourinary (38 CFR § 4.115b)
- Erectile Dysfunction (DC 7522) — 0% + SMC(k)

### Neurological (38 CFR § 4.124a)
- Migraine Headaches (DC 8100)
- Peripheral Neuropathy (DC 8515)

### Digestive (38 CFR § 4.114)
- Irritable Bowel Syndrome (DC 7319)

---

## Security & Privacy

| Protection | Implementation |
|-----------|---------------|
| Encryption | AES-128 via Fernet symmetric encryption |
| Key Derivation | PBKDF2-SHA256, 480,000 iterations (NIST standard) |
| Storage | SQLite database, encrypted fields |
| Permissions | Directory: `chmod 700` | Files: `chmod 600` |
| Network | No data sent to servers except Claude API during AI generation |
| AI Generation | Only symptom data sent to Anthropic API — no SSN, DOB, or identifying info required |

### What is sent to the Claude API?
Only the following is transmitted when you use AI language generation:
- Condition name and diagnostic code
- Your symptom descriptions (as you entered them)
- Service branch and MOS
- 38 CFR rating criteria for context

Your name, SSN, DOB, and other identifying information are **never** required by or sent to the API.

---

## Output File Security

All output files are created with `chmod 600` (owner read/write only).
They contain Protected Health Information (PHI).

**Recommended handling:**
- Store on an encrypted drive
- Do not email without encryption
- Share only with: your VSO, accredited claims agent, or VA personnel
- Shred physical copies when no longer needed

---

## Legal Notice

This tool is a **preparation aid only**. It is not legal advice, medical advice,
or an official VA product. Final disability ratings are determined by VA adjudicators
based on C&P exam findings and all available evidence.

**Always consult a VSO before filing:**
- DAV (Disabled American Veterans): dav.org
- VFW: vfw.org  
- American Legion: legion.org
- AMVETS: amvets.org
- Find a VSO: va.gov/decision-reviews/get-help-with-review-request/

---

## Project Structure

```
va_bdd_tool/
├── main.py                    # Entry point, main workflow orchestration
├── setup.py                   # Installation verification
├── requirements.txt           # Python dependencies
├── README.md                  # This file
├── modules/
│   ├── eligibility.py         # BDD eligibility checker & deadline calculator
│   ├── condition_intake.py    # Symptom interview & rating estimation
│   ├── rating_engine.py       # 38 CFR § 4.25 combined ratings math
│   ├── ai_language.py         # Claude API integration for claim language
│   ├── secure_storage.py      # Encrypted local storage (Fernet/PBKDF2)
│   └── outputs.py             # Document generation (TXT + PDF)
└── data/
    └── conditions_db.py       # 38 CFR Part 4 conditions database
```

---

## Extending the Tool

To add new conditions:
1. Add an entry to `data/conditions_db.py` following the existing schema
2. Add the condition key to the appropriate body system in `BODY_SYSTEMS`
3. Add secondary condition prompts to `SECONDARY_PROMPTS` if applicable

The rating criteria, DBQ questions, exam tips, and nexus tips are all data-driven —
no code changes required for new conditions.

---

*Built to serve those who served.*
