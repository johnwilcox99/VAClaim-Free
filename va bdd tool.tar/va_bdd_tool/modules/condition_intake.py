"""
Condition Intake Module
Interactive guided interview for each claimed condition.
Collects symptoms, estimates ratings, flags secondary conditions,
and triggers AI language generation.
"""

from typing import Dict, List, Optional, Tuple
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box
import questionary
from questionary import Style

from data.conditions_db import CONDITIONS_DB, BODY_SYSTEMS, SECONDARY_PROMPTS
from modules.rating_engine import benefit_of_the_doubt

STYLE = Style([
    ("qmark", "fg:cyan bold"),
    ("question", "bold"),
    ("answer", "fg:green bold"),
    ("pointer", "fg:cyan bold"),
    ("highlighted", "fg:cyan bold"),
    ("selected", "fg:green"),
    ("separator", "fg:yellow"),
    ("instruction", "fg:gray italic"),
])

console = Console()


def display_rating_criteria(condition: Dict) -> None:
    """Display the 38 CFR rating tiers for a condition in a formatted table."""
    table = Table(
        title=f"38 CFR Rating Criteria — {condition['name']}",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
        padding=(0, 1),
        expand=False,
    )
    table.add_column("Rating", style="bold green", justify="center", width=8)
    table.add_column("Required Findings", style="white")

    for pct, desc in sorted(condition["rating_criteria"].items(), reverse=True):
        color = (
            "bold green" if pct >= 50
            else "green" if pct >= 30
            else "yellow" if pct >= 10
            else "dim"
        )
        table.add_row(f"[{color}]{pct}%[/{color}]", desc)

    console.print()
    console.print(table)
    console.print(
        f"\n[dim]CFR Reference: {condition.get('cfr_reference', 'See 38 CFR Part 4')}[/dim]\n"
    )


def collect_condition_symptoms(condition_key: str, service_info: Dict) -> Optional[Dict]:
    """
    Run the interactive symptom interview for a specific condition.
    Returns a dict of collected symptoms, estimated rating, and metadata.
    Returns None if the user skips.
    """
    if condition_key not in CONDITIONS_DB:
        console.print(f"[red]Condition '{condition_key}' not found in database.[/red]")
        return None

    condition = CONDITIONS_DB[condition_key]

    console.print()
    console.print(Panel(
        f"[bold cyan]{condition['name']}[/bold cyan]\n"
        f"[dim]Diagnostic Code: {condition['diagnostic_code']} | {condition.get('cfr_reference', '')}[/dim]\n\n"
        "Answer the following questions as they apply to your WORST symptoms — not an average day.\n"
        "Under 38 CFR § 4.3 (Benefit of the Doubt), borderline cases are resolved in your favor.",
        title=f"📋 Condition Intake",
        border_style="cyan"
    ))

    # Show rating criteria upfront so veteran understands what they're documenting
    display_rating_criteria(condition)

    # Confirm veteran wants to proceed
    proceed = questionary.confirm(
        f"Do you want to claim [bold]{condition['name']}[/bold] as a service-connected condition?",
        default=True,
        style=STYLE,
    ).ask()

    if not proceed:
        return None

    # ── Symptom Collection ─────────────────────────────────────────────
    symptoms = {}
    answers = {}

    console.print(
        "\n[bold yellow]Answer each question about your symptoms. "
        "Be thorough — more detail = stronger claim.[/bold yellow]\n"
    )

    for i, question in enumerate(condition["dbq_questions"], 1):
        console.print(f"  [dim]{i}/{len(condition['dbq_questions'])}[/dim]")
        answer = questionary.text(
            question,
            instruction="(describe in detail — be specific, use measurements/frequencies where possible)",
            style=STYLE,
        ).ask()

        if answer is None:
            continue
        if answer.strip():
            answers[question] = answer.strip()

    symptoms["answers"] = answers

    # ── Key Measurements (where applicable) ─────────────────────────
    measurements = {}
    if condition.get("key_measurements"):
        console.print()
        console.print(Panel(
            "[bold]Objective Measurements[/bold]\n"
            "These measurements will be taken at your C&P exam. "
            "Enter your current measured values if known (or leave blank).",
            border_style="yellow", padding=(0, 1)
        ))
        for measurement in condition["key_measurements"]:
            val = questionary.text(
                f"{measurement}",
                instruction="(enter numeric value or leave blank if unknown)",
                style=STYLE,
            ).ask()
            if val and val.strip():
                measurements[measurement] = val.strip()

    symptoms["measurements"] = measurements

    # ── Functional Impact ────────────────────────────────────────────
    console.print()
    console.print("[bold yellow]Functional Impact[/bold yellow]")
    console.print("[dim]This section is critical — how the condition affects your life drives the rating.[/dim]\n")

    work_impact = questionary.text(
        "How does this condition affect your ability to WORK? (missed days, job tasks you cannot do, etc.)",
        style=STYLE,
    ).ask()

    daily_impact = questionary.text(
        "How does it affect your DAILY LIFE? (sleep, driving, household tasks, personal care, hobbies)",
        style=STYLE,
    ).ask()

    flare_frequency = questionary.text(
        "How often do you have flare-ups or bad days? (daily, weekly, monthly — describe)",
        style=STYLE,
    ).ask()

    symptoms["work_impact"] = work_impact or ""
    symptoms["daily_impact"] = daily_impact or ""
    symptoms["flare_frequency"] = flare_frequency or ""

    # ── Treatment History ────────────────────────────────────────────
    console.print()
    treatments = questionary.checkbox(
        "What treatments have you received or are currently receiving for this condition?",
        choices=[
            "Physical therapy",
            "Prescription pain medication (opioids or NSAIDs)",
            "Prescription non-pain medication (steroids, antidepressants, etc.)",
            "Surgery",
            "Injections (cortisone, nerve block, etc.)",
            "Bracing or orthotics",
            "CPAP or other devices",
            "Mental health therapy (CBT, EMDR, etc.)",
            "Chiropractic care",
            "No treatment (condition is untreated)",
            "Other",
        ],
        style=STYLE,
    ).ask()

    symptoms["treatments"] = treatments or []

    if treatments and "Other" in treatments:
        other_treatment = questionary.text("Describe other treatment:", style=STYLE).ask()
        symptoms["other_treatment"] = other_treatment or ""

    # ── In-Service Event/Nexus ──────────────────────────────────────
    console.print()
    console.print("[bold yellow]Service Connection (Nexus)[/bold yellow]")
    console.print("[dim]Describe the in-service event, injury, or exposure that caused or contributed to this condition.[/dim]\n")

    in_service_events = []
    event = questionary.text(
        "Describe the in-service event, injury, or exposure (be specific with dates/locations if known):",
        style=STYLE,
    ).ask()
    if event and event.strip():
        in_service_events.append(event.strip())

    documented = questionary.select(
        "Is this event documented in your Service Treatment Records (STRs)?",
        choices=[
            "Yes — medical record / sick call visit exists",
            "Yes — incident report or duty injury report",
            "Partially — some documentation exists",
            "No — not documented but it happened",
            "Unknown — I haven't reviewed my STRs yet",
        ],
        style=STYLE,
    ).ask()

    symptoms["in_service_events"] = in_service_events
    symptoms["strs_documentation"] = documented or "Unknown"

    # ── Buddy Statement ─────────────────────────────────────────────
    buddy = questionary.confirm(
        "Do you have fellow service members or family who can write a buddy statement about this condition?",
        default=True,
        style=STYLE,
    ).ask()
    symptoms["buddy_statement_available"] = buddy

    # ── Estimate Rating ─────────────────────────────────────────────
    estimated_rating = _estimate_rating(condition, symptoms)

    console.print()
    _display_rating_estimate(condition, estimated_rating, symptoms)

    # ── Exam Tips ──────────────────────────────────────────────────
    if condition.get("exam_tips"):
        console.print()
        console.print(Panel(
            "[bold yellow]⚡ C&P Exam Tips — Read Before Your Exam[/bold yellow]\n\n"
            + "\n".join(f"  • {tip}" for tip in condition["exam_tips"]),
            border_style="yellow",
        ))

    return {
        "condition_key": condition_key,
        "condition_name": condition["name"],
        "diagnostic_code": condition["diagnostic_code"],
        "cfr_reference": condition.get("cfr_reference", ""),
        "symptoms": symptoms,
        "in_service_events": in_service_events,
        "estimated_rating": estimated_rating,
        "bilateral_pair": condition.get("bilateral_pair"),
        "secondary_conditions": condition.get("secondary_conditions", []),
    }


def _estimate_rating(condition: Dict, symptoms: Dict) -> int:
    """
    Heuristic rating estimator based on collected symptoms.
    Uses benefit of the doubt (§ 4.3) to push to higher tier when borderline.
    This is an estimate — the actual C&P exam and VA adjudication determines the final rating.
    """
    criteria = condition["rating_criteria"]
    ratings = sorted(criteria.keys(), reverse=True)
    answers = symptoms.get("answers", {})
    measurements = symptoms.get("measurements", {})
    work_impact = symptoms.get("work_impact", "")
    all_text = " ".join(str(v) for v in answers.values()) + " " + work_impact

    all_text_lower = all_text.lower()

    # Mental health conditions — use symptom keyword scoring
    if condition.get("body_system") == "mental_health":
        score = 0

        # 70-100% markers
        if any(kw in all_text_lower for kw in [
            "suicid", "self-harm", "unable to work", "lost job", "can't function",
            "hospitalized", "danger", "violent", "hallucin", "delusion", "total",
        ]):
            score += 40

        # 50-70% markers
        if any(kw in all_text_lower for kw in [
            "panic attack", "every week", "daily", "can't sleep", "relationship",
            "impaired", "reduced productivity", "not reliable",
        ]):
            score += 25

        # 30-50% markers
        if any(kw in all_text_lower for kw in [
            "sometimes", "intermittent", "occasional", "mild memory", "sleep problem",
            "weekly", "monthly panic",
        ]):
            score += 15

        if score >= 40 and 70 in ratings:
            return 70
        elif score >= 25 and 50 in ratings:
            return 50
        elif score >= 15 and 30 in ratings:
            return 30
        elif 10 in ratings:
            return 10
        return 0

    # Musculoskeletal — use range of motion measurements
    if "forward flexion" in str(measurements).lower() or "flexion" in str(measurements).lower():
        for key, val in measurements.items():
            if "forward flexion" in key.lower() or "flexion" in key.lower():
                try:
                    degrees = float(''.join(filter(lambda c: c.isdigit() or c == '.', val)))
                    # Apply to lumbar/cervical criteria
                    if "lumbar" in condition["name"].lower() or "lumbosacral" in condition["name"].lower():
                        if degrees <= 30 and 20 in ratings:
                            return 20
                        elif degrees <= 60 and 10 in ratings:
                            return 10
                    elif "cervical" in condition["name"].lower() or "neck" in condition["name"].lower():
                        if degrees <= 15 and 30 in ratings:
                            return 30
                        elif degrees <= 30 and 20 in ratings:
                            return 20
                        elif degrees <= 40 and 10 in ratings:
                            return 10
                except (ValueError, TypeError):
                    pass

    # General: use functional impact keywords for all other conditions
    if any(kw in all_text_lower for kw in [
        "constant", "every day", "cannot work", "prostrat", "severe", "completely",
        "50%", "60%", "continuous",
    ]):
        return max(ratings) if ratings else 0

    if any(kw in all_text_lower for kw in [
        "frequent", "most days", "significant", "substantial", "moderate to severe",
        "requires device", "cpap", "requires medication",
    ]):
        mid = ratings[len(ratings) // 2] if len(ratings) > 1 else ratings[0]
        return mid

    if any(kw in all_text_lower for kw in [
        "occasional", "sometimes", "mild", "intermittent", "manageable",
    ]):
        return ratings[-2] if len(ratings) >= 2 else ratings[-1]

    # Default: lowest non-zero rating
    non_zero = [r for r in ratings if r > 0]
    return min(non_zero) if non_zero else 0


def _display_rating_estimate(condition: Dict, estimated_rating: int, symptoms: Dict) -> None:
    """Display the estimated rating and rating tier explanation."""
    criteria = condition["rating_criteria"]

    # Find if we're borderline between tiers
    sorted_ratings = sorted(criteria.keys(), reverse=True)
    current_idx = sorted_ratings.index(estimated_rating) if estimated_rating in sorted_ratings else -1
    higher_rating = sorted_ratings[current_idx - 1] if current_idx > 0 else None

    color = (
        "bold green" if estimated_rating >= 50
        else "green" if estimated_rating >= 30
        else "yellow" if estimated_rating >= 10
        else "dim white"
    )

    content = (
        f"[bold]Estimated Rating:[/bold] [{color}]{estimated_rating}%[/{color}]\n\n"
        f"[bold]Based on:[/bold] {criteria.get(estimated_rating, 'Symptoms as reported')}\n"
    )

    if higher_rating:
        higher_desc = criteria.get(higher_rating, "")
        content += (
            f"\n[bold yellow]⬆  To reach {higher_rating}%:[/bold yellow]\n"
            f"[dim]{higher_desc}[/dim]\n\n"
            "[italic]Under 38 CFR § 4.3 (Benefit of the Doubt), if your symptoms are borderline, "
            f"the rating will be resolved at {higher_rating}% in your favor.[/italic]"
        )

    console.print(Panel(
        content,
        title="📊 Rating Estimate",
        border_style="green" if estimated_rating >= 30 else "yellow",
    ))


# ── Body System & Condition Selection ──────────────────────────────────

def select_conditions_to_claim() -> List[str]:
    """
    Interactive menu for the veteran to select which conditions to claim.
    Returns a list of condition keys.
    """
    console.print()
    console.print(Panel(
        "[bold cyan]Condition Selection[/bold cyan]\n\n"
        "Select the body systems that apply to your claimed conditions.\n"
        "You can select multiple systems and multiple conditions within each.\n\n"
        "[dim]Tip: When in doubt, claim it. You can always withdraw a condition later, "
        "but you cannot go back and claim conditions retroactively to your BDD effective date.[/dim]",
        title="📋 Step 2: Your Conditions",
        border_style="cyan"
    ))

    selected_conditions = []

    # Multi-select body systems
    system_choices = [
        questionary.Choice(
            title=info["label"],
            value=system_key,
        )
        for system_key, info in BODY_SYSTEMS.items()
    ]

    selected_systems = questionary.checkbox(
        "Which body systems are affected? (select all that apply)",
        choices=system_choices,
        style=STYLE,
    ).ask()

    if not selected_systems:
        console.print("[yellow]No systems selected.[/yellow]")
        return []

    # For each selected system, pick conditions
    for system_key in selected_systems:
        system_info = BODY_SYSTEMS[system_key]
        available = [
            c for c in system_info["conditions"] if c in CONDITIONS_DB
        ]

        if not available:
            continue

        condition_choices = [
            questionary.Choice(
                title=CONDITIONS_DB[c]["name"],
                value=c,
            )
            for c in available
        ]

        console.print(f"\n[bold cyan]{system_info['label']}[/bold cyan]")

        chosen = questionary.checkbox(
            "Which conditions are you claiming?",
            choices=condition_choices,
            style=STYLE,
        ).ask()

        if chosen:
            selected_conditions.extend(chosen)

    return selected_conditions


def run_secondary_condition_checks(
    claimed_conditions: List[str],
) -> List[str]:
    """
    Check for secondary conditions based on what's already been claimed.
    Returns a list of additional condition keys the veteran should consider.
    """
    suggested = []
    already_claimed = set(claimed_conditions)

    console.print()
    console.print(Panel(
        "[bold yellow]Secondary Condition Check[/bold yellow]\n\n"
        "Based on your claimed conditions, the following secondary conditions may also apply.\n"
        "Secondary conditions are caused or aggravated by your primary service-connected conditions\n"
        "and are fully claimable under 38 CFR § 3.310.",
        border_style="yellow"
    ))

    for cond_key in claimed_conditions:
        if cond_key not in SECONDARY_PROMPTS:
            continue

        for secondary_key, prompt_text in SECONDARY_PROMPTS[cond_key]:
            if secondary_key in already_claimed or secondary_key in suggested:
                continue

            console.print(f"\n  [cyan]ℹ  {prompt_text}[/cyan]")
            add = questionary.confirm(
                f"  Add [bold]{CONDITIONS_DB.get(secondary_key, {}).get('name', secondary_key)}[/bold] as a secondary condition?",
                default=True,
                style=STYLE,
            ).ask()

            if add and secondary_key in CONDITIONS_DB:
                suggested.append(secondary_key)
                already_claimed.add(secondary_key)
                console.print(
                    f"  [green]✓ Added {CONDITIONS_DB[secondary_key]['name']} "
                    f"as secondary to {CONDITIONS_DB.get(cond_key, {}).get('name', cond_key)}[/green]"
                )

    return suggested
