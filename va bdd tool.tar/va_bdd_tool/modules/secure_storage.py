"""
Secure Local Storage - PII/HIPAA Protection
All veteran data is encrypted at rest using Fernet symmetric encryption.
The encryption key is derived from a user-set password using PBKDF2.
No data ever leaves the veteran's computer.
"""

import os
import json
import base64
import sqlite3
import hashlib
import secrets
import getpass
from pathlib import Path
from typing import Optional, Any, Dict
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


class SecureStorage:
    """
    Encrypted local storage for veteran PII and claim data.
    Uses AES-128 via Fernet, with PBKDF2-derived keys from a user password.
    All data stays local — no network calls from this module.
    """

    SALT_FILE = ".va_salt"
    DB_FILE = "va_claim_data.db"

    def __init__(self, storage_dir: Optional[Path] = None):
        if storage_dir is None:
            storage_dir = Path.home() / ".va_bdd_tool"
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # Set restrictive permissions on the storage directory
        os.chmod(self.storage_dir, 0o700)

        self.salt_path = self.storage_dir / self.SALT_FILE
        self.db_path = self.storage_dir / self.DB_FILE
        self._fernet: Optional[Fernet] = None
        self._initialized = False

    # ─────────────────────────────────────────
    # Key Derivation & Authentication
    # ─────────────────────────────────────────

    def _get_or_create_salt(self) -> bytes:
        """Get existing salt or generate a new one."""
        if self.salt_path.exists():
            with open(self.salt_path, "rb") as f:
                return f.read()
        else:
            salt = secrets.token_bytes(32)
            with open(self.salt_path, "wb") as f:
                f.write(salt)
            os.chmod(self.salt_path, 0o600)
            return salt

    def _derive_key(self, password: str, salt: bytes) -> bytes:
        """Derive an encryption key from the password using PBKDF2."""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,  # NIST recommended minimum
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

    def initialize(self, password: str) -> bool:
        """
        Initialize the secure storage with a password.
        Returns True if successfully opened (or created) the encrypted store.
        """
        try:
            salt = self._get_or_create_salt()
            key = self._derive_key(password, salt)
            self._fernet = Fernet(key)

            # Test encryption/decryption to verify password
            self._init_database()

            # Verify password by attempting to read a test value
            test = self._db_get_raw("_auth_check")
            if test is None:
                # First time — write auth check
                self._db_set_raw("_auth_check", self._fernet.encrypt(b"verified").decode())
            else:
                # Verify existing auth
                self._fernet.decrypt(test.encode())  # Will throw if wrong password

            self._initialized = True
            return True

        except Exception:
            self._fernet = None
            self._initialized = False
            return False

    def is_new_profile(self) -> bool:
        """Check if this is a new (first-time) profile."""
        return not self.salt_path.exists()

    # ─────────────────────────────────────────
    # Database Layer
    # ─────────────────────────────────────────

    def _init_database(self):
        """Initialize SQLite database schema."""
        with sqlite3.connect(self.db_path) as conn:
            os.chmod(self.db_path, 0o600)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS vault (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT DEFAULT (datetime('now'))
                )
            """)
            conn.commit()

    def _db_set_raw(self, key: str, encrypted_value: str):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO vault (key, value, updated_at) VALUES (?, ?, datetime('now'))",
                (key, encrypted_value)
            )
            conn.commit()

    def _db_get_raw(self, key: str) -> Optional[str]:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute("SELECT value FROM vault WHERE key = ?", (key,)).fetchone()
            return row[0] if row else None

    def _db_delete_raw(self, key: str):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM vault WHERE key = ?", (key,))
            conn.commit()

    def _db_list_keys(self, prefix: str = "") -> list:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT key FROM vault WHERE key LIKE ? AND key NOT LIKE '\\_%' ESCAPE '\\'",
                (f"{prefix}%",)
            ).fetchall()
            return [r[0] for r in rows]

    # ─────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────

    def _assert_initialized(self):
        if not self._initialized or self._fernet is None:
            raise RuntimeError("SecureStorage not initialized. Call initialize() first.")

    def set(self, key: str, value: Any):
        """Encrypt and store a value."""
        self._assert_initialized()
        json_bytes = json.dumps(value).encode()
        encrypted = self._fernet.encrypt(json_bytes).decode()
        self._db_set_raw(key, encrypted)

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve and decrypt a value."""
        self._assert_initialized()
        raw = self._db_get_raw(key)
        if raw is None:
            return default
        try:
            decrypted = self._fernet.decrypt(raw.encode())
            return json.loads(decrypted)
        except Exception:
            return default

    def delete(self, key: str):
        """Delete a stored value."""
        self._assert_initialized()
        self._db_delete_raw(key)

    def list_keys(self, prefix: str = "") -> list:
        """List all non-internal keys, optionally filtered by prefix."""
        self._assert_initialized()
        return self._db_list_keys(prefix)

    def export_plaintext(self, export_path: Path) -> bool:
        """
        Export all claim data as plaintext JSON to a user-chosen location.
        The veteran explicitly chooses the export path.
        """
        self._assert_initialized()
        try:
            data = {}
            for key in self.list_keys():
                data[key] = self.get(key)

            with open(export_path, "w") as f:
                json.dump(data, f, indent=2, default=str)
            os.chmod(export_path, 0o600)
            return True
        except Exception:
            return False

    def wipe_all(self):
        """Securely wipe all stored data."""
        self._assert_initialized()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM vault")
            conn.commit()

    def storage_location(self) -> str:
        return str(self.storage_dir)


def prompt_password_setup(storage: SecureStorage) -> bool:
    """
    Guide the veteran through setting up or entering their storage password.
    Returns True on success.
    """
    from rich.console import Console
    from rich.panel import Panel
    console = Console()

    is_new = storage.is_new_profile()

    if is_new:
        console.print(Panel(
            "[bold yellow]🔐 Create Your Secure Storage Password[/bold yellow]\n\n"
            "Your claim data will be encrypted on your computer with a password only you know.\n"
            "[red]IMPORTANT:[/red] If you forget this password, your data cannot be recovered.\n"
            "Store this password somewhere safe (password manager, written in a secure location).\n\n"
            "[dim]Your data is stored at: " + storage.storage_location() + "[/dim]",
            title="Security Setup",
            border_style="yellow"
        ))

        while True:
            pw1 = getpass.getpass("  Create password: ")
            if len(pw1) < 8:
                console.print("[red]Password must be at least 8 characters.[/red]")
                continue
            pw2 = getpass.getpass("  Confirm password: ")
            if pw1 != pw2:
                console.print("[red]Passwords do not match. Try again.[/red]")
                continue
            break

        if storage.initialize(pw1):
            console.print("[green]✓ Secure storage created successfully.[/green]\n")
            return True
        else:
            console.print("[red]Failed to create secure storage.[/red]")
            return False

    else:
        console.print(Panel(
            "[bold cyan]🔐 Enter Your Storage Password[/bold cyan]\n\n"
            "[dim]Stored at: " + storage.storage_location() + "[/dim]",
            border_style="cyan"
        ))

        for attempt in range(3):
            pw = getpass.getpass("  Password: ")
            if storage.initialize(pw):
                console.print("[green]✓ Secure storage unlocked.[/green]\n")
                return True
            else:
                remaining = 2 - attempt
                if remaining > 0:
                    console.print(f"[red]Incorrect password. {remaining} attempts remaining.[/red]")

        console.print("[red]Too many failed attempts. Exiting for security.[/red]")
        return False
