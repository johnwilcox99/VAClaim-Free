#!/usr/bin/env python3
"""
VA BDD Claim Tool — Setup & Installation Verification
"""
import subprocess
import sys
import os
from pathlib import Path


def check_python():
    if sys.version_info < (3, 9):
        print("❌  Python 3.9+ required. Download at https://python.org")
        sys.exit(1)
    print(f"✓  Python {sys.version_info.major}.{sys.version_info.minor}")


def install_requirements():
    req_file = Path(__file__).parent / "requirements.txt"
    print("\nInstalling required packages...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", str(req_file), "--quiet"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print("✓  All packages installed successfully")
    else:
        print(f"⚠  Some packages may have failed:\n{result.stderr}")


def verify_imports():
    packages = {
        "rich": "Terminal UI",
        "cryptography": "Data encryption",
        "anthropic": "AI language generation",
        "questionary": "Interactive menus",
        "dateutil": "Date calculation",
    }
    optional = {
        "reportlab": "PDF generation (optional)",
    }

    print("\nVerifying package imports:")
    all_ok = True

    for pkg, desc in packages.items():
        try:
            __import__(pkg)
            print(f"  ✓  {pkg} — {desc}")
        except ImportError:
            print(f"  ❌  {pkg} — {desc} [REQUIRED]")
            all_ok = False

    for pkg, desc in optional.items():
        try:
            __import__(pkg)
            print(f"  ✓  {pkg} — {desc}")
        except ImportError:
            print(f"  ○  {pkg} — {desc} [NOT INSTALLED — PDF output disabled]")

    return all_ok


def check_api_key():
    key = os.environ.get("ANTHROPIC_API_KEY")
    if key:
        print(f"\n✓  ANTHROPIC_API_KEY found in environment (AI features enabled)")
    else:
        print("\n⚠  ANTHROPIC_API_KEY not set in environment.")
        print("   You can set it before running:")
        print("   Mac/Linux: export ANTHROPIC_API_KEY='your-key-here'")
        print("   Windows:   set ANTHROPIC_API_KEY=your-key-here")
        print("   Or enter it interactively when the tool prompts you.")


def main():
    print("=" * 60)
    print("  VA BDD Claim Tool — Setup Verification")
    print("=" * 60)

    check_python()
    install_requirements()
    all_ok = verify_imports()
    check_api_key()

    print("\n" + "=" * 60)
    if all_ok:
        print("✅  Setup complete. Run the tool with:")
        print()
        print("       python main.py")
        print()
    else:
        print("⚠  Some required packages are missing.")
        print("   Run: pip install -r requirements.txt")
    print("=" * 60)


if __name__ == "__main__":
    main()
